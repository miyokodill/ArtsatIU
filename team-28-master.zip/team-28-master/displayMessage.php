<?php
//Comment
session_start();


function formatDate($date)
{
    return date('F, j, Y', strtotime($date));
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Check to see if user is logged in
if (!isset($_SESSION["uid"])) {
    header("Location: ./loginForm.php");
} else {
    $sessionUser = $_SESSION["uid"];
}

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php?error=sql");
}
//SELECT receiverID, senderID, date FROM message WHERE senderID = 1  GROUP BY receiverID UNION SELECT receiverID, senderID, date FROM message WHERE receiverID = 1 GROUP BY senderID ORDER BY date;
$sql = "SELECT receiverID, senderID, date FROM message WHERE senderID = $sessionUser  GROUP BY receiverID UNION SELECT receiverID, senderID, date FROM message WHERE receiverID = $sessionUser GROUP BY senderID ORDER BY date";


$result = mysqli_query($conn, $sql);
$IDarray = array();
//attempting to create unique array of user convos
while ($row = mysqli_fetch_assoc($result)){
    //Checking to see if num already in array and see if id is not the logged in users
    if (!in_array($row["receiverID"], $IDarray) && $row["receiverID"] != $sessionUser) {
        array_push($IDarray, $row["receiverID"]);
    }
    if (!in_array($row["senderID"], $IDarray) && $row["senderID"] != $sessionUser) {
        array_push($IDarray, $row["senderID"]);
    }
}
//This determines whether or not to display admin tab on nav
$adminSelect = "SELECT * FROM user WHERE userID=$sessionUser";
$adminResult = mysqli_query($conn, $adminSelect);
$adminAssoc = mysqli_fetch_assoc($adminResult);
$adminInfo = (int)$adminAssoc["admin"];
$admin = false;
if($adminInfo == 1){
    $admin = true;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//assets.iu.edu/web/3.2.x/css/iu-framework.min.css?2020-12-03-2">
    <link rel="stylesheet" href="//assets.iu.edu/brand/3.2.x/brand.min.css?2020-12-03">
    <link rel="stylesheet" href="//assets.iu.edu/search/3.2.x/search.min.css?2020-12-03">

    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-regular.woff" rel="preload" type="font/woff2">
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-bold.woff" rel="preload" type="font/woff2">
    <link rel="preconnect" href="https://fonts.iu.edu" crossorigin="">
    <link rel="dns-prefetch" href="https://fonts.iu.edu">
    <link rel="stylesheet" type="text/css" href="//fonts.iu.edu/style.css?family=BentonSans:regular,bold|BentonSansCond:regular,bold|GeorgiaPro:regular|BentonSansLight:regular">
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">

    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="//assets.iu.edu/web/3.2.x/css/iu-framework.min.css?2020-12-03-2">
    <link rel="stylesheet" href="//assets.iu.edu/brand/3.2.x/brand.min.css?2020-12-03">
    <link rel="stylesheet" href="//assets.iu.edu/search/3.2.x/search.min.css?2020-12-03">

    <link href="//www.iu.edu/favicon.ico" rel="icon" />
    <link href="//www.iu.edu/favicon.ico" rel="shortcut icon" />
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/element/a57bc5975bc720b0/default+en.css">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/style/look/v4/default.css">

    <!-- Include Stylesheets -->
    <link href="brand.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/brand2.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/index.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="https://assets.iu.edu/favicon.ico" rel="shortcut icon" type="image/x-icon">
    <link rel="stylesheet" href="./css/displayMessage.css">
    <link href="https://fonts.iu.edu/style.css?family=BentonSans:regular,bold|BentonSansCond:regular|GeorgiaPro:regular" media="screen" rel="stylesheet" type="text/css" />

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://assets.iu.edu/search/3.2.x/search.js"></script>
    <script src="https://assets.iu.edu/web/3.2.x/js/iu-framework.min.js"></script>
    <script src="https://styleguide.iu.edu/_assets/js/site.js"></script>
    <script src="rvt.js"></script>
    <title>Arts@IU</title>
</head>

<body class="mahogany no-banner has-page-title landmarks">
<header id="header">
        <!-- Navigation Skip -->
        <div id="skipnav">
            <ul>
            <li><a href="#content">Skip to Content</a></li>
            <li><a href="#nav-main">Skip to Main Navigation</a></li>
            <li><a href="#search">Skip to Search</a></li>
            </ul>
            <hr>
        </div>
        <!-- Branding Bar -->
        <div id="branding-bar" class="iu" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity" role="complementary" aria-labelledby="campus-name">
            <div class="row pad">
                    <img src="./images/trident-large.png" alt="" />
                    <p id="iu-campus">
                        <a href="@@url" title="Indiana University">
                            <span id="campus-name" class="show-on-desktop" itemprop="name">Indiana University</span>
                            <span class="show-on-tablet" itemprop="name">Indiana University</span>
                            <span class="show-on-mobile" itemprop="name">IU</span>
                        </a>
                    </p>
            </div>
        </div>
        <div id="offCanvas" class="hide-for-large" role="navigation" aria-label="Mobile">
            <button class="menu-toggle button hide-for-large" data-toggle="iu-menu">Menu</button>
            <div id="iu-menu" class="off-canvas position-right off-canvas-items" data-off-canvas=""
                data-position="right">
                <div class="mobile off-canvas-list" itemscope="itemscope"
                    itemtype="http://schema.org/SiteNavigationElement">
                    <ul>
                        <li class=""><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                        <li class="has-children">
                        <a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                            <ul class="children">
                                <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                                <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                                <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                                <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                                <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                                <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                                <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                                <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                            </ul>
                        </li>
                        <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                        <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                        <?php echo '<li><a href="./profile.php' . "?uid=$loggedInUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                        <li><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                        <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                        <?php
                        if ($admin == true) {
                            echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                        }
                        ?>

                </div>
            </div>
        </div>
        <!-- Site Header -->
        <div class="site-header" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
            <div class="row pad">
                <h1 id="h1Title"><a class="title" href="index.php" itemprop="department">Arts@IU</a></h1>
            </div>
        </div>
        <!-- Nav Bar -->
        <div id="nav-main-sticky-wrapper" class="sticky-nav" style="height: 54px;">
        <nav aria-label="Main" id="nav-main" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" class="main show-for-large dropdown" style="width: 1428px;">
                <ul class="row pad">
                    <li class="show-on-sticky home"><a href="./index.php" aria-label="Home">Home</a></li>
                    <li class="first"><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                    <li><a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                        <ul class="children">
                        <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                            <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                            <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                            <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                            <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                            <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                            <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                            <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                        </ul>
                    </li>
                    <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                    <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                    <?php echo '<li><a href="./profile.php' . "?uid=$sessionUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                    <li class="second"><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                    <li><a href="./displayMessage.php" itemprop="url" class="current"><span itemprop="name">Messages</span></a></li>
                    <?php
                        if($admin == true){
                            echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                        }

                    ?>
                    <li><a class="login-bttn" href="./php/logout.php" itemprop="url"><span itemprop="name">Logout</span></a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- No Section Nav -->
    <main class="no-section-nav">

        <!-- White Background -->
        <div id="main-content">
            <div class="breakout bg-none section" id="content">
                <div class="row">
                    <div class="container">
                            <h2>Messages for: <?php echo $_SESSION["fname"] . ' ' .  $_SESSION["lname"]; ?></h2>
                            <div class="msgBox">


                                <?php
                                foreach ($IDarray as $value) {
                                    //echo $value . "<br>";
                                    //query to get latest message between user and logged in person
                                    $latestMessageSQL = "SELECT receiverID, senderID, content, date, time FROM message WHERE senderID = $sessionUser AND receiverID = $value OR senderID = $value AND receiverID = $sessionUser ORDER BY date DESC, time DESC LIMIT 1 ";
                                    //Executing query
                                    $latestMessageResult = mysqli_query($conn, $latestMessageSQL);
                                    $row = mysqli_fetch_assoc($latestMessageResult);
                                    //Getting info from query
                                    $senderID = $row["senderID"];
                                    $receiverID = $row["receiverID"];
                                    $content = $row["content"];
                                    $date = $row["date"];
                                    $time = $row["time"];
                                    $lookupUser;

                                    //Want to display profile pic of person user is messaging, not the logged in user.
                                    if ($senderID != $_SESSION["uid"]) {
                                        $lookupUser = $senderID;
                                    } else if ($receiverID != $_SESSION["uid"]) {
                                        $lookupUser = $receiverID;
                                    }

                                    $profileSQL = "SELECT fname, lname, profilePic FROM user_profile WHERE userID=$lookupUser";
                                    $profileSQLResults = mysqli_query($conn, $profileSQL);
                                    $profileResultArray = mysqli_fetch_assoc($profileSQLResults);
                                    $profilePic = $profileResultArray["profilePic"];


                                    //Have to get info from user table if profile hasn't been set up yet. 
                                    $userSQL = "SELECT fname, lname FROM user WHERE userID=$lookupUser";
                                    $userSQLResult = mysqli_query($conn, $userSQL);
                                    $userSQLResultArray = mysqli_fetch_assoc($userSQLResult);
                                    $fname = $userSQLResultArray["fname"];
                                    $lname = $userSQLResultArray["lname"];



                                    echo '<a href="./message.php?uid=' . $lookupUser . '">';
                                    echo '<div class="msg">';
                                    echo '<div class="topMsg">';
                                    //Checking to see if user has profile pic
                                    if (is_null($profilePic)) {
                                        echo ' <img src="./images/grayAvatar.png" alt="avatar">';
                                    } else {
                                        echo '<img src="../profilePics/' . $profilePic . '" alt="avatar">';
                                    }
                                    echo '<p>' . $fname . ' ' . $lname . '</p>';
                                    echo '<p>Date: ' . formatDate($date) . '</p>';
                                    echo '</div>';
                                    echo '<div class="bottomMsg">';
                                    if(strlen($content) <= 150){
                                    echo '<p>Last Message: ' . $content . '</p>';
                                    }else{
                                        echo '<p>Last Message: ' . substr($content,0,150) . " ..." .  '</p>';
                                    }
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</a>';
                                }
                                ?>
                            </div> <!-- Msg box  -->
                    </div><!-- Container  -->
                </div><!-- row -->
            </div><!-- breakout -->
        </div><!-- main -->
    </main>
        <!-- Social Media Belt  -->
    <div class="section bg-mahogany bg-dark belt">
        <div class="row pad">
            <div class="one-half belt-nav">
                <ul class="inline">
                        <li><a href="https://www.iuauditorium.com/">IU Auditorium</a></li>
                        <li><a href="https://admissions.indiana.edu/life/arts.html">IU Arts</a></li>
                </ul>
            </div>
            <div class="one-half">
                <div class="invert border">
                    <ul class="social">
                        <li><a class="icon-twitter" href="#">Twitter</a></li>
                        <li><a class="icon-facebook" href="#">Facebook</a></li>
                        <li><a class="icon-instagram" href="#">Instagram</a></li>
                        <li><a class="icon-youtube" href="#/iu">YouTube</a></li>
                        <li><a class="icon-linkedin" href="#">LinkedIn</a></li>
                        <li><a class="icon-googleplus" href="#">Google Plus</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer  -->
    <footer id="footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
        <div class="row pad">
            <p class="signature">
                <a href="https://www.iu.edu" class="signature-link signature-img"><img src="./images/iu-sig-formal.svg" alt="Indiana University" /></a>
            </p>

            <p class="copyright">
                <span class="line-break"><a href="https://accessibility.iu.edu/assistance" id="accessibility-link" title="Having trouble accessing this web page content? Please visit this page for assistance.">Accessibility</a> | <a href="/privacy" id="privacy-policy-link">Privacy Notice</a></span>
                <span class="hide-on-mobile"> | </span>
                <a href="https://www.iu.edu/copyright/index.html">Copyright</a> &#169; 2020 <span class="line-break-small">The Trustees of <a href="https://www.iu.edu/" itemprop="url"><span itemprop="name">Indiana University</span></a></span>
            </p>
        </div>
    </footer>
    </div>
    <?php mysqli_close($conn);?>
</body>

</html>