<?php
function formatDate($date)
{
    return date('F, j, Y', strtotime($date));
}

//Checking if user is logged in
session_start();
//$_SESSION["uid"] = 8;
if (!isset($_SESSION["uid"])) {
    header("Location: ./loginForm.php");
    exit();
} else {
    $sessionUser = (int) $_SESSION["uid"];
}

//Connect to database
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ./index.php?error=sql");
    exit();
}

//Check admin status
$adminStatus = "SELECT * FROM user WHERE userID=$sessionUser";
$adminResult = mysqli_query($conn, $adminStatus);
$adminArray = mysqli_fetch_assoc($adminResult);
$admin = (int) $adminArray["admin"];

if($admin == 1){
    $admin1 = true;
}

//See if the user is an admin
if ($admin != 1) {
    header("Location: ./index.php?error=admin");
    exit();
}

$reportSelect = "SELECT reporterID, count(videoID) AS countRep, videoID FROM report GROUP by videoID ORDER BY count(videoID) DESC";
$reportResult = mysqli_query($conn, $reportSelect);
?>



<!DOCTYPE HTML>
<html lang="en" class="">

<head>
    <meta charset="UTF-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Arts@IU</title>

    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Fonts -->
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-regular.woff" rel="preload" type="font/woff2">
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-bold.woff" rel="preload" type="font/woff2">
    <link rel="preconnect" href="https://fonts.iu.edu" crossorigin="">
    <link rel="dns-prefetch" href="https://fonts.iu.edu">
    <link rel="stylesheet" type="text/css" href="//fonts.iu.edu/style.css?family=BentonSans:regular,bold|BentonSansCond:regular,bold|GeorgiaPro:regular|BentonSansLight:regular">
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">

    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="//assets.iu.edu/web/3.2.x/css/iu-framework.min.css?2020-12-03-2">
    <link rel="stylesheet" href="//assets.iu.edu/brand/3.2.x/brand.min.css?2020-12-03">
    <link rel="stylesheet" href="//assets.iu.edu/search/3.2.x/search.min.css?2020-12-03">

    <link href="//www.iu.edu/favicon.ico" rel="icon" />
    <link href="//www.iu.edu/favicon.ico" rel="shortcut icon" />
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/element/a57bc5975bc720b0/default+en.css">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/style/look/v4/default.css">

    <!-- Include Stylesheets -->
    <link href="css/brand.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/brand2.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="https://assets.iu.edu/favicon.ico" rel="shortcut icon" type="image/x-icon">

    <style>
        body {
            margin: 0;
            padding: 0;
        }
    </style>

    <!-- Include Javascript -->

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://assets.iu.edu/search/3.2.x/search.js"></script>
    <script src="https://assets.iu.edu/web/3.2.x/js/iu-framework.min.js"></script>
    <script src="https://styleguide.iu.edu/_assets/js/site.js"></script>


    <script>
        // IUSearch.init({
        //     dynamicCSS: true,
        //     CX : {
        //         site: '014109358301568672738:jrgtuxfo2-0', // IU Admissions TEST
        //         all: '014109358301568672738:-tr9prjhqju' // IUPUI TEST
        //     }
        // });
    </script>

</head>

<body class="mahogany no-banner has-page-title landmarks">

    <!-- Include Javascript -->
    <header id="header">
        <!-- Navigation Skip -->
        <div id="skipnav">
            <ul>
                <li><a href="#content">Skip to Content</a></li>
                <li><a href="#nav-main">Skip to Main Navigation</a></li>
                <li><a href="#search">Skip to Search</a></li>
            </ul>
            <hr>
        </div>
        <!-- Branding Bar -->
        <div id="branding-bar" class="iu" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity" role="complementary" aria-labelledby="campus-name">
            <div class="row pad">
                <img src="images/trident-large.png" alt="" />
                <p id="iu-campus">
                    <a href="@@url" title="Indiana University">
                        <span id="campus-name" class="show-on-desktop" itemprop="name">Indiana University</span>
                        <span class="show-on-tablet" itemprop="name">Indiana University</span>
                        <span class="show-on-mobile" itemprop="name">IU</span>
                    </a>
                </p>
            </div>
        </div>
        <div id="offCanvas" class="hide-for-large" role="navigation" aria-label="Mobile">
            <button class="menu-toggle button hide-for-large" data-toggle="iu-menu">Menu</button>
            <div id="iu-menu" class="off-canvas position-right off-canvas-items" data-off-canvas=""
                data-position="right">
                <div class="mobile off-canvas-list" itemscope="itemscope"
                    itemtype="http://schema.org/SiteNavigationElement">
                    <ul>
                        <li class=""><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                        <li class="has-children">
                        <a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                            <ul class="children">
                                <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                                <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                                <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                                <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                                <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                                <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                                <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                                <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                            </ul>
                        </li>
                        <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                        <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                        <?php echo '<li><a href="./profile.php' . "?uid=$loggedInUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                        <li><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                        <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                        <?php
                        if ($admin == true) {
                            echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                        }
                        ?>

                </div>
            </div>
        </div>
        <!-- Site Header -->
        <div class="site-header" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
            <div class="row pad">
                <h1><a class="title" href="index.php" itemprop="department">Arts@IU</a></h1>
            </div>
        </div>
        <!-- Nav Bar -->
        <div id="nav-main-sticky-wrapper" class="sticky-nav" style="height: 54px;">
        <nav aria-label="Main" id="nav-main" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" class="main show-for-large dropdown" style="width: 1428px;">
                <ul class="row pad">
                    <li class="show-on-sticky home"><a href="./index.php" aria-label="Home">Home</a></li>
                    <li class="first"><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                    <li><a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                        <ul class="children">
                        <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                            <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                            <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                            <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                            <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                            <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                            <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                            <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                        </ul>
                    </li>
                    <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                    <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                    <?php echo '<li><a href="./profile.php' . "?uid=$sessionUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                    <li class="second"><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                    <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                    <?php
                        if($admin1 == true){
                            echo '<li><a href="./adminHome.php" itemprop="url" class="current"<span itemprop="name">Admin</span></a></li>';
                        }

                    ?>
                    <li><a class="login-bttn" href="./php/logout.php" itemprop="url"><span itemprop="name">Logout</span></a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Content Top -->
    <main style="min-height: 184px;">
        <div class="content-top">
            <div class="section breadcrumbs">
                <div class="row">
                    <div class="layout">
                        <ul itemscope="itemscope" itemtype="http://schema.org/BreadcrumbList">
                            <li itemprop="itemListElement" itemscope="itemscope" itemtype="http://schema.org/ListItem"><a href="#" itemprop="item"><span itemprop="name">Admin</span></a>
                                <meta content="1" itemprop="position">
                            </li>
                            <li class="current" itemprop="itemListElement" itemscope="itemscope" itemtype="http://schema.org/ListItem"><span itemprop="name">ADMIN</span>
                                <meta content="2" itemprop="position">
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="section page-title bg-none">
                <div class="row">
                    <div class="layout">
                        <h1>ABOUT</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- Nav - Main Content  -->
        <div id="main-content" data-gtm-vis-recent-on-screen-30688157_28="369" data-gtm-vis-first-on-screen-30688157_28="369" data-gtm-vis-total-visible-time-30688157_28="100" data-gtm-vis-has-fired-30688157_28="1">
            <!-- Explanation -->
            <div class="collapsed bg-none section" id="content">
                <div class="row">
                    <div class="layout">
                        <div class="text">
                            <h3>Admin Controls</h3>
                            <p>The Administrative center is a page to allow employees to either push a video to the home page or report a video. Previous admins can also give administrative powers to other users as well.</p>
                        </div>
                    </div><!-- /.layout -->
                </div>
            </div>
        
            <!-- Display Results -->
            <div id="content" class="bg-none section extra-space"> 
                <div class="row">
                    <div class="layout">
                        <div class="text">
                            <h4>Video Reports</h4>
                            <?php
                            echo '<table>';
                            echo '<tr>';
                            echo '<td># of Reports</td>';
                            echo '<td>Title</td>';
                            echo '<td>Video Link</td>';
                            echo '<td>Remove Report</td>';
                            echo '</tr>';

                            while ($row = mysqli_fetch_assoc($reportResult)) {
                                $vid = $row["videoID"];
                                $reportVidSelect = "SELECT * FROM video WHERE videoID=$vid";
                                $reportVidSelectResult = mysqli_query($conn, $reportVidSelect);
                                $reportVidArr = mysqli_fetch_assoc($reportVidSelectResult);
                                $vidID = $reportVidArr["videoID"];
                                $numRep = $row["countRep"];
                                $title = $reportVidArr["title"];
                                $link = '<a href="./watchVideo.php?vid=' . $vidID . '">' . $title . '</a>';
                                $removeReport = '<a href="./php/removeReport.php?vid=' . $vid . '">Remove Report</a>';

                                echo '<tr>';
                                echo '<td>' . $numRep . '</td>';
                                echo '<td>' . $title . '</td>';
                                echo '<td>' . $link . '</td>';
                                echo '<td>' . $removeReport . '</td>';
                                echo '</tr>';
                            }
                            echo '</table>';

                            ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>



        <!-- Side Navigation  -->
        <div class="section-nav show-for-large" id="section-nav">
            <div class="row">
                <nav itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" aria-label="Section" data-parent-url="/request/index">
                    <ul>
                        <li class=""><a href="./adminHome.php" itemprop="url" class="current"><span itemprop="name">Admin Home</span></a></li>
                        <li class=""><a href="./adminAdd.php" itemprop="url" class=""><span itemprop="name">Add Admin</span></a></li>
                        <li class=""><a href="./addEvent.php" itemprop="url" class=""><span itemprop="name">Add Event</span></a></li>
                    </ul>
                </nav>
            </div>
        </div>

    </main>

    <!-- Social Media Belt  -->
    <div class="section bg-mahogany bg-dark belt">
        <div class="row pad">
            <div class="one-half belt-nav">
                <ul class="inline">
                        <li><a href="https://www.iuauditorium.com/">IU Auditorium</a></li>
                        <li><a href="https://admissions.indiana.edu/life/arts.html">IU Arts</a></li>
                </ul>
            </div>
            <div class="one-half">
                <div class="invert border">
                    <ul class="social">
                        <li><a class="icon-twitter" href="#">Twitter</a></li>
                        <li><a class="icon-facebook" href="#">Facebook</a></li>
                        <li><a class="icon-instagram" href="#">Instagram</a></li>
                        <li><a class="icon-youtube" href="#/iu">YouTube</a></li>
                        <li><a class="icon-linkedin" href="#">LinkedIn</a></li>
                        <li><a class="icon-googleplus" href="#">Google Plus</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer  -->
    <footer id="footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
        <div class="row pad">
            <p class="signature">
                <a href="https://www.iu.edu" class="signature-link signature-img"><img src="images/iu-sig-formal.svg" alt="Indiana University" /></a>
            </p>

            <p class="copyright">
                <span class="line-break"><a href="https://accessibility.iu.edu/assistance" id="accessibility-link" title="Having trouble accessing this web page content? Please visit this page for assistance.">Accessibility</a> | <a href="/privacy" id="privacy-policy-link">Privacy Notice</a></span>
                <span class="hide-on-mobile"> | </span>
                <a href="https://www.iu.edu/copyright/index.html">Copyright</a> &#169; 2020 <span class="line-break-small">The Trustees of <a href="https://www.iu.edu/" itemprop="url"><span itemprop="name">Indiana University</span></a></span>
            </p>
        </div>
    </footer>

    <?php mysqli_close($conn);?>
</body>

</html>