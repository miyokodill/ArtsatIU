# team-28
This repository contains Team 28's Capstone Project -- IU Arts Hub
This website seeks to serve the Arts at IU by providing students and faculty a way to continue practicing and sharing their talents among IU peers through an IU exclusive content platform.