<?php
/*
DANIEL TODO ON paymentHandler.php:
1.)Grab the $_SESSION["vid"] and save to a variable
2.Write a query to insert into ticketSale that the user made the payment
3.)Execute the query and take them to watchVideo.php?vid=vidNumber
*/

//NEED TO FIX DATE AND TIME so DB has proper date and time of purchase
session_start();

//Checking to make sure this is being accessed by a logged in user
if(isset($_SESSION["uid"])){
    $sessionUser = (int)$_SESSION["uid"];
    $vidPaid = (int)$_SESSION["vid"];
    $vidPrice = (int)$_SESSION["price"];
    $date = date('Y-m-d');
    $time = time();
}
else{
    header("Location: ./loginForm.php");
    exit();
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
//In the future will want session var to take back to prev location
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ./home.php?error=sql");
}

//Write query to insert info into DB
$ticketSQL = "INSERT INTO ticketSale (buyerID,  videoID, price, purchased, date, time) VALUES ($sessionUser, $vidPaid, $vidPrice, 1,'$date','$time')";
$result = mysqli_query($conn, $ticketSQL);
if($result){
    echo 'SUCCESS';
    header("Location: ./watchVideo.php?vid=$vidPaid");
}
else{
    echo 'FAIL';
}

mysqli_close($conn);



?>