<?php
session_start();


function formatDate($date)
{
    return date('F, j, Y', strtotime($date));
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Check to see if user is logged in
$sessionUser = $_SESSION["uid"];

if (!isset($_SESSION["uid"])) {
    header("Location: ./loginForm.php");
    exit();
}


//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);

//Check DB connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php?error=sql");
}

//Get likes from the session user
$likessql = "SELECT category, COUNT(category) AS popular FROM video WHERE videoID IN
(SELECT videoID FROM likes WHERE userID=$sessionUser)
GROUP BY category
ORDER BY popular DESC
LIMIT 1";
$likesResult = mysqli_query($conn, $likessql);
$likesRow = mysqli_fetch_assoc($likesResult);
$likesCategory = $likesRow["category"];
$likesPopular = (int) $likesRow["popular"];

//See if the user has a favorite category
if ($likesPopular > 0) {
    //Grab video
    $videosql = "SELECT * FROM video WHERE featured=1 AND category='$likesCategory'";
    $videoResult = mysqli_query($conn, $videosql);
    $videoRow = mysqli_fetch_assoc($videoResult);
    $vid = $videoRow["videoID"];
} else {
    //Grab video the first featured video
    $videosql = "SELECT * FROM video WHERE featured=1
    LIMIT 1";
    $videoResult = mysqli_query($conn, $videosql);
    $videoRow = mysqli_fetch_assoc($videoResult);
    $vid = $videoRow["videoID"];
}

//Query and data retrieval for video user clicked on
$sql = "SELECT title, vidDescription, uploadDate, ticketPrice, ownerID, vidLocation FROM video WHERE videoID=$vid";
$result = mysqli_query($conn, $sql);
//Retrieving info about the vid 
if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $vidSrc = $row["vidLocation"];
    $title = $row["title"];
    $vidDescription = $row["vidDescription"];
    $ownerID = (int)$row["ownerID"];
    $uploadDate = $row["uploadDate"];
    $price = (int) $row["ticketPrice"];
}
$date = date('Y-m-d');

$musicVids = "SELECT * FROM video WHERE category='music' AND launchDate<='$date' ORDER BY rand()";
$musicResults = mysqli_query($conn, $musicVids);

$art = "SELECT * FROM video WHERE category='art' AND launchDate<='$date' ORDER BY rand()";
$artResults = mysqli_query($conn, $art);

$theater = "SELECT * FROM video WHERE category='theater' AND launchDate<='$date' ORDER BY rand()";
$theaterResults = mysqli_query($conn, $theater);

$comedy = "SELECT * FROM video WHERE category='comedy' AND launchDate<='$date' ORDER BY rand()";
$comedyResults = mysqli_query($conn, $comedy);

$photo = "SELECT * FROM video WHERE category='photography' AND launchDate<='$date' ORDER BY rand()";
$photoResults = mysqli_query($conn, $photo);

$freeVids = "SELECT * FROM video WHERE ticketPrice = 0 AND launchDate<='$date' ORDER BY rand()";
$freeResults = mysqli_query($conn, $freeVids);

//Check admin status
$adminStatus = "SELECT * FROM user WHERE userID=$sessionUser";
$adminResult = mysqli_query($conn, $adminStatus);
$adminArray = mysqli_fetch_assoc($adminResult);
$admin1 = (int) $adminArray["admin"];

if ($admin1 == 1) {
    $admin = true;
}
?>

<!DOCTYPE HTML>
<html lang="en" class="">

<head>
    <meta charset="UTF-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Arts@IU</title>

    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Fonts -->
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-regular.woff" rel="preload" type="font/woff2">
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-bold.woff" rel="preload" type="font/woff2">
    <link rel="preconnect" href="https://fonts.iu.edu" crossorigin="">
    <link rel="dns-prefetch" href="https://fonts.iu.edu">
    <link rel="stylesheet" type="text/css" href="//fonts.iu.edu/style.css?family=BentonSans:regular,bold|BentonSansCond:regular,bold|GeorgiaPro:regular|BentonSansLight:regular">
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">

    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="//assets.iu.edu/web/3.2.x/css/iu-framework.min.css?2020-12-03-2">
    <link rel="stylesheet" href="//assets.iu.edu/brand/3.2.x/brand.min.css?2020-12-03">
    <link rel="stylesheet" href="//assets.iu.edu/search/3.2.x/search.min.css?2020-12-03">

    <link href="//www.iu.edu/favicon.ico" rel="icon" />
    <link href="//www.iu.edu/favicon.ico" rel="shortcut icon" />
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/element/a57bc5975bc720b0/default+en.css">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/style/look/v4/default.css">

    <!-- Include Stylesheets -->
    <link href="brand.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/brand2.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/index.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="https://assets.iu.edu/favicon.ico" rel="shortcut icon" type="image/x-icon">

    <style>
        body {
            margin: 0;
            padding: 0;
        }

        .rel {
            position: relative;
        }

        .bleft {
            position: absolute;
            bottom: -70px;
            font-size: 14px;
            margin: 0;
            padding: 0;
            background-color: white;
            color: black;
            padding-left: 10px;
            padding-right: 10px;
            opacity: 0.8;
        }

        .modal {
    display: none;
    /* Hidden by default */
    position: fixed;
    /* Stay in place */
    z-index: 1;
    /* Sit on top */
    left: 0;
    top: 0;
    width: 100%;
    /* Full width */
    height: 100%;
    /* Full height */
    overflow: auto;
    /* Enable scroll if needed */
    background-color: rgb(0, 0, 0);
    /* Fallback color */
    background-color: rgba(0, 0, 0, 0.4);
    /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    /* 15% from the top and centered */
    padding: 20px;
    border: 1px solid #888;
    width: 70%;
    /* Could be more or less, depending on screen size */
}
.modalInner{
    display: flex;
    flex-flow: column wrap;
    justify-content: center;
    align-items: center;
    padding-top: 15px;
    padding-left: 10px;
    padding-right: 10px;
}

.modal-content img {
    height: 100px;
}


        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .vidDisplay a:hover {
            color: #990000;
        }

        .vidDisplay a {
            color: #45382B;
            font-family: 'BentonSans';
        }
    </style>

    <!-- Include Javascript -->

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://assets.iu.edu/search/3.2.x/search.js"></script>
    <script src="https://assets.iu.edu/web/3.2.x/js/iu-framework.min.js"></script>
    <script src="https://styleguide.iu.edu/_assets/js/site.js"></script>


    <script>

    </script>

</head>

<body class="mahogany no-banner has-page-title landmarks">

    <!-- Include Javascript -->
    <header id="header">
        <!-- Navigation Skip -->
        <div id="skipnav">
            <ul>
                <li><a href="#content">Skip to Content</a></li>
                <li><a href="#nav-main">Skip to Main Navigation</a></li>
                <li><a href="#search">Skip to Search</a></li>
            </ul>
            <hr>
        </div>
        <!-- Branding Bar -->
        <div id="branding-bar" class="iu" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity" role="complementary" aria-labelledby="campus-name">
            <div class="row pad">
                <img src="images/trident-large.png" alt="" />
                <p id="iu-campus">
                    <a href="@@url" title="Indiana University">
                        <span id="campus-name" class="show-on-desktop" itemprop="name">Indiana University</span>
                        <span class="show-on-tablet" itemprop="name">Indiana University</span>
                        <span class="show-on-mobile" itemprop="name">IU</span>
                    </a>
                </p>
            </div>
        </div>
        <div id="offCanvas" class="hide-for-large" role="navigation" aria-label="Mobile">
            <button class="menu-toggle button hide-for-large" data-toggle="iu-menu">Menu</button>
            <div id="iu-menu" class="off-canvas position-right off-canvas-items" data-off-canvas=""
                data-position="right">
                <div class="mobile off-canvas-list" itemscope="itemscope"
                    itemtype="http://schema.org/SiteNavigationElement">
                    <ul>
                        <li class=""><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                        <li class="has-children">
                        <a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                            <ul class="children">
                                <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                                <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                                <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                                <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                                <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                                <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                                <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                                <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                            </ul>
                        </li>
                        <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                        <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                        <?php echo '<li><a href="./profile.php' . "?uid=$loggedInUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                        <li><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                        <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                        <?php
                        if ($admin == true) {
                            echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                        }
                        ?>

                </div>
            </div>
        </div>
        <!-- Site Header -->
        <div class="site-header" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
            <div class="row pad">
                <h1><a class="title" href="index.php" itemprop="department">Arts@IU</a></h1>
            </div>
        </div>
        <!-- Nav Bar -->
        <div id="nav-main-sticky-wrapper" class="sticky-nav" style="height: 54px;">
            <nav aria-label="Main" id="nav-main" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" class="main show-for-large dropdown" style="width: 1428px;">
                <ul class="row pad">
                    <li class="show-on-sticky home"><a href="./index.php" aria-label="Home">Home</a></li>
                    <li class="first"><a href="./index.php" itemprop="url" class="current"><span itemprop="name">Home</span></a></li>
                    <li><a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                        <ul class="children">
                            <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                            <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                            <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                            <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                            <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                            <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                            <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                            <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                        </ul>
                    </li>
                    <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                    <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                    <?php echo '<li><a href="./profile.php' . "?uid=$loggedInUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                    <li><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                    <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                    <?php
                    if ($admin == true) {
                        echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                    }

                    ?>
                    <li><a class="login-bttn" href="./php/logout.php" itemprop="url"><span itemprop="name">Logout</span></a></li>
                </ul>
            </nav>
        </div>


    </header>

    <!-- No Section Nav -->
    <main class="no-section-nav">

        <!-- White Background -->
        <div id="main-content">
            <div class="breakout bg-none section" id="content">
                <div class="row">
                    <div class="layout">
                        <!-- Main Video -->
                        <div class="grid two-thirds">
                            <div class="grid-item" style="height: 296px;">
                                <div class="content">
                                    <div class="home vid">
                                        <h2><?php echo $title; ?></h2>
                                        <video height="450" controls>
                                            <?php
                                            echo '<source src="../videos/' . $vidSrc . '" type="video/mp4">';
                                            ?>
                                        </video>
                                        <div class="description">
                                            <p><strong>Description:</strong></p>
                                            <p class="pad"><?php echo $vidDescription; ?></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- Events -->
                        <div class="grid one-third">
                            <div class="grid-item" style="height: 296px;">
                                <div class="feature">
                                    <div class="content home-events">
                                        <h3 class="section-title">Events</h3>
                                        <ul class="feed">
                                            <?php
                                            $date = date("Y-m-d");
                                            $eventSQL = "SELECT * FROM event WHERE beginDate >= '$date' ORDER BY rand() LIMIT 5";
                                            $eventResult = mysqli_query($conn, $eventSQL);
                                            while ($row = mysqli_fetch_assoc($eventResult)) {
                                                $eventID = $row["eventID"];
                                                $eventTitle = $row["title"];
                                                echo '<li class="feed-item feed-item--small news">
                                                <figure class="media">
                                                    <img src="https://placehold.it/152x152" alt="News Photo" />
                                                </figure>

                                                <div class="content">';
                                                echo'
                                                    <h2 class="title"><a href="./eventInfo.php?eventID=' . $eventID . '">' . $eventTitle . '</a></h2>';
                                                echo'
                                                </div>
                                            </li>';
                                            }

                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div><!-- /.layout -->
                </div>

                <!-- Red Background -->
                <div class="bg-crimson bg-dark section">
                    <div class="row">
                        <div class="layout">
                            <div class="grid thirds">
                                <div class="grid-item" style="height: 693.547px;">
                                    <div class="feature">
                                        <figure class="media image media--border" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
                                            <img alt="Indiana University students are pictured on their laptop" src="https://luddy.indiana.edu/images/about/luddy.llc-makerspace.jpg">
                                        </figure>
                                        <div class="content">
                                            <h3 class="title">Start Uploading Videos</h3>
                                            <p></p>
                                            <p>Using Arts@IU, students and organizations can start live streaming their work for others to see. Users can start by either uploading prerecorded videos or start live streaming from the site. There's also the option to help students and organizations to sell tickets for their videos, supporting the arts at Indiana University.</p>
                                            <p></p>
                                            <a class="button external" href="./upload.php">Upload a Video</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="grid-item" style="height: 693.547px;">
                                    <div class="feature">
                                        <figure class="media image media--border" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
                                            <img alt="Indiana University's Philharmonic'" src="https://music.indiana.edu/images/degrees-programs/ensembles/ensembles-jazz-combo.jpg">
                                        </figure>
                                        <div class="content">
                                            <h3 class="title">Watch Videos</h3>
                                            <p></p>
                                            <p>Indiana University prides itself on its outstanding liberal arts program. Our goal is to allow everyone the ability to enjoy the arts, no matter where they are in the world. Our selection has a wide range of categories, such as music, theatre, art demonstrations, and more.</p>
                                            <p></p>
                                            <a class="button external" href="./displayVideos.php?category=free">View our Selection</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="grid-item" style="height: 693.547px;">
                                    <div class="feature">
                                        <figure class="media image media--border" itemscope="itemscope" itemtype="http://schema.org/ImageObject">
                                            <img alt="Indiana University students have a way to connect with each other through our service" src="https://itnews.iu.edu/media/USE.eTexts.student.groups.large.jpg">
                                        </figure>
                                        <div class="content">
                                            <h3 class="title">Connect with Others</h3>
                                            <p></p>
                                            <p>Through our service, we are able to allow other students to message and connect with each other. They are able to leave comments and build a community around art. Users can easily look up other student's work and reach out to compliment or collab.</p>
                                            <p></p>
                                            <a class="button external" href="./users.php">Find Users</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.layout -->
                    </div>
                </div>
                <div class="breakout bg-none section" id="content">
                    <div class="row">
                        <div class="layout">
                            <h2>Videos</h2>
                            <?php


                            $inc = 0;
                            if (mysqli_num_rows($artResults) > 0) {
                                echo '<h4 class="arth4">Graphic Arts</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($artResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=art">More Videos</a>

                            <?php
                            $inc = 0;
                            if (mysqli_num_rows($musicResults) > 0) {
                                echo '<h4 class="arth4">Music</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($musicResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=music">More Videos</a>

                            <?php
                            $inc = 0;
                            if (mysqli_num_rows($comedyResults) > 0) {
                                echo '<h4 class="arth4">Comedy</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($comedyResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=comedy">More Videos</a>

                            <?php
                            $inc = 0;
                            $danceSQL = "SELECT * FROM video WHERE category='dance' AND launchDate<='$date' ORDER BY rand()";
                            $danceResults = mysqli_query($conn, $danceSQL);
                            if (mysqli_num_rows($danceResults) > 0) {
                                echo '<h4 class="arth4">Dance</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($danceResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=dance">More Videos</a>

                            <?php
                            $inc = 0;
                            $photoSQL = "SELECT * FROM video WHERE category='photography' AND launchDate<='$date' ORDER BY rand()";
                            $photoResults = mysqli_query($conn, $photoSQL);
                            if (mysqli_num_rows($photoResults) > 0) {
                                echo '<h4 class="arth4">Photography</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($photoResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=photography">More Videos</a>

                            <?php
                            $inc = 0;
                            $theaterSQL = "SELECT * FROM video WHERE category='theater' AND launchDate<='$date' ORDER BY rand()";
                            $theaterResults = mysqli_query($conn, $theaterSQL);
                            if (mysqli_num_rows($theaterResults) > 0) {
                                echo '<h4 class="arth4">Theater</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($theaterResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=theater">More Videos</a>

                            <?php
                            $inc = 0;
                            if (mysqli_num_rows($freeResults) > 0) {
                                echo '<h4 class="arth4">Free Videos</h4>';
                                echo '<div class="vidDisplay">';
                                while ($row = mysqli_fetch_assoc($freeResults)) {
                                    $inc += 1;
                                    if ($inc == 6) {
                                        break;
                                    }
                                    echo '<div>';
                                    echo '<a class="rel" href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<img class="img" src="../thumbnails/' . $row["thumbnailLocation"] . '" width="140px" height="150px">';
                                    if ((int)$row["ticketPrice"] > 0) {
                                        echo '<p class="bleft">Price: $' . $row["ticketPrice"] . ' </p>';
                                    }
                                    echo "<p>" . $row["title"] . "</p>";
                                    echo '</a>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                            ?>
                            <a id="moreVidBttn" class="login-bttn" href="./displayVideos.php?category=free">More Videos</a>

                        </div>
                    </div>


                </div>


            </div>

    </main>

    <!-- Social Media Belt  -->
    <div class="section bg-mahogany bg-dark belt">
        <div class="row pad">
            <div class="one-half belt-nav">
                <ul class="inline">
                    <li><a href="https://www.iuauditorium.com/">IU Auditorium</a></li>
                    <li><a href="https://admissions.indiana.edu/life/arts.html">IU Arts</a></li>
                </ul>
            </div>
            <div class="one-half">
                <div class="invert border">
                    <ul class="social">
                        <li><a class="icon-twitter" href="#">Twitter</a></li>
                        <li><a class="icon-facebook" href="#">Facebook</a></li>
                        <li><a class="icon-instagram" href="#">Instagram</a></li>
                        <li><a class="icon-youtube" href="#/iu">YouTube</a></li>
                        <li><a class="icon-linkedin" href="#">LinkedIn</a></li>
                        <li><a class="icon-googleplus" href="#">Google Plus</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer  -->
    <footer id="footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
        <div class="row pad">
            <p class="signature">
                <a href="https://www.iu.edu" class="signature-link signature-img"><img src="images/iu-sig-formal.svg" alt="Indiana University" /></a>
            </p>

            <p class="copyright">
                <span class="line-break"><a href="https://accessibility.iu.edu/assistance" id="accessibility-link" title="Having trouble accessing this web page content? Please visit this page for assistance.">Accessibility</a> | <a href="/privacy" id="privacy-policy-link">Privacy Notice</a></span>
                <span class="hide-on-mobile"> | </span>
                <a href="https://www.iu.edu/copyright/index.html">Copyright</a> &#169; 2020 <span class="line-break-small">The Trustees of <a href="https://www.iu.edu/" itemprop="url"><span itemprop="name">Indiana University</span></a></span>
            </p>
        </div>
    </footer>

    <?php mysqli_close($conn); ?>
    <!-- https://www.w3schools.com/howto/howto_css_modals.asp -->
    <!-- The Modal for improper access of a page on the site-->
    <div id="myModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="modalInner">
                <img src="./images/trident-large.png">
                <p class="modalText">You have tried to access a file on the website in an improper way and have been redirected to the home page.</p>
            </div>
        </div>

    </div>
    <script>
        let url_string = window.location.href;
        let url = new URL(url_string);
        if (url.searchParams.get("error") == "access" || url.searchParams.get("error") == "admin" || url.searchParams.get("error") == "getVid") {
            //alert("You have tried to access a page improperly and have been redirected to the home page");

            // Get the modal
            var modal = document.getElementById("myModal");

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks on the button, open the modal

            modal.style.display = "block";


            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
            if (url.searchParams.get("error") == "admin") {
                let text = document.querySelector(".modalText").innerHTML = "You have tried to access an admin page without admin privileges and have been redirected to the home page.";
            }
            if (url.searchParams.get("error") == "getVid") {
                let text = document.querySelector(".modalText").innerHTML = "You have tried to watch a video that does not exist or has not launched yet and have been redirected to the home page.";
            }


        }
    </script>
</body>

</html>