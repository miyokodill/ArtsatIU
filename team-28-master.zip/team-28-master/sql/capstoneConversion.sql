ERD CONVERSION

---------------------------------------------------------------------------
STRONG ENTS
user(userID, fname, lname, email, gender, standing, bio, profilePic, contentPref, admin, followers,strikes, banned)

video(videoID, title, description, date, livestream, category, ticketPrice, views, likes, userID)
---------------------------------------------------------------------------
WEAK ENTS
comments(userID, videoID, time, date, content)

violationTicket(adminID, videoID, userID, reason, justification, appealed)

message(receiverID, senderID, content, date, time)

ticketSales(buyerID, userID, videoID, price, paid)

---------------------------------------------------------------------------
---------------------------------------------------------------------------

TABLE CREATION
-----------------

CREATE TABLE user
(
userID INT NOT NULL AUTO_INCREMENT,
fname VARCHAR(80) NOT NULL,
lname VARCHAR(80) NOT NULL,
email VARCHAR(256) NOT NULL,
banned BOOL NOT NULL,
admin BOOL NOT NULL,
PRIMARY KEY (userID)
)
ENGINE=INNODB;
-------------------------------------------------------------------------------
CREATE TABLE user_profile
(
	userID INT NOT NULL,
	fname VARCHAR(256) NOT NULL,
	lname VARCHAR(256) NOT NULL,
	gender VARCHAR(256) NOT NULL,
	standing VARCHAR(40) NOT NULL,
	bio LONGTEXT,
	profilePic VARCHAR(256),
	pronouns VARCHAR(256),
	major VARCHAR(256),
	FOREIGN KEY (userID) REFERENCES user(userID)
)
ENGINE=INNODB;

-------------------------------------------------------------------------------
CREATE TABLE video
(
videoID INT NOT NULL AUTO_INCREMENT,
title VARCHAR(80) NOT NULL,
vidDescription VARCHAR(80) NOT NULL,
uploadDate DATE NOT NULL,
category VARCHAR(80) NOT NULL,
ticketPrice INT NOT NULL,
ownerID INT NOT NULL,
thumbnailLocation VARCHAR(256) NOT NULL,
vidLocation VARCHAR(256) NOT NULL,
PRIMARY KEY (videoID),
FOREIGN KEY (ownerID) REFERENCES user(userID)
)
ENGINE=INNODB;
-------------------------------------------------------------------------------
CREATE TABLE comments
(
userID INT NOT NULL,
videoID INT NOT NULL,
date DATE NOT NULL,
time TIME NOT NULL,
content LONGTEXT NOT NULL,
FOREIGN KEY (userID) REFERENCES user(userID),
FOREIGN KEY (videoID) REFERENCES video(videoID)
)
ENGINE=INNODB;
-------------------------------------------------------------------------------
CREATE TABLE violationTicket
(
adminID INT NOT NULL,
videoID INT NOT NULL,
creatorID INT NOT NULL,
justification LONGTEXT NOT NULL,
FOREIGN KEY (adminID) REFERENCES user(userID),
FOREIGN KEY (videoID) REFERENCES video(videoID),
FOREIGN KEY (creatorID) REFERENCES user(userID)
)
ENGINE=INNODB;
--------------------------------------------------------------------------------
CREATE TABLE message
(
receiverID INT NOT NULL,
senderID INT NOT NULL,
content LONGTEXT NOT NULL,
date DATE NOT NULL,
time TIME NOT NULL,
messageID int NOT NULL,
PRIMARY KEY (messageID),
FOREIGN KEY (receiverID) REFERENCES user(userID),
FOREIGN KEY (senderID) REFERENCES user(userID)
)
ENGINE=INNODB;
--------------------------------------------------------------------------------
CREATE TABLE ticketSale
(
buyerID INT NOT NULL,  
videoID INT NOT NULL,  
price INT NOT NULL, 
purchased BOOL NOT NULL,
date DATE NOT NULL,
time TIME NOT NULL,
FOREIGN KEY (buyerID) REFERENCES user(userID),
FOREIGN KEY (videoID) REFERENCES video(videoID)
)
ENGINE=INNODB;
----------------------------------------------------------------------------------
CREATE TABLE interests
(
interestID INT AUTO_INCREMENT,
name VARCHAR(256) NOT NULL,
PRIMARY KEY (interestID)
)
ENGINE=INNODB;
-----------------------------------------------------------------------------------
CREATE TABLE userInterest
(
userID INT NOT NULL,
interestID INT NOT NULL,
FOREIGN KEY (userID) REFERENCES user(userID),
FOREIGN KEY (interestID) REFERENCES interests(interestID)
)
ENGINE=INNODB;
---------------------------------------------------------------------------------
CREATE TABLE user_followers
(
	followerID INT,
	followingID INT,
	FOREIGN KEY (followerID) REFERENCES user(userID),
	FOREIGN KEY (followingID) REFERENCES user(userID)
	
)
ENGINE=INNODB;
------------------------------------------------------------------------------
CREATE TABLE likes
(
	userID INT NOT NULL,
	videoID INT NOT NULL,
	FOREIGN KEY (userID) REFERENCES user(userID),
	FOREIGN KEY (videoID) REFERENCES video(videoID)
)
ENGINE=INNODB;
------------------------------------------------------------------------------------
CREATE TABLE views
(
	userID INT NOT NULL,
	videoID INT NOT NULL,
	FOREIGN KEY (userID) REFERENCES user(userID),
	FOREIGN KEY (videoID) REFERENCES video(videoID)
)
ENGINE=INNODB;
----------------------------------------------------------------------------------------
CREATE TABLE report
(
	reporterID INT NOT NULL,
	videoID INT NOT NULL,
	date DATE NOT NULL,
	time TIME NOT NULL,
	FOREIGN KEY (reporterID) REFERENCES user(userID),
	FOREIGN KEY (videoID) REFERENCES video(videoID)
)
ENGINE=INNODB;

CREATE TABLE view
(
	userID INT NOT NULL,
	videoID INT NOT NULL,
	FOREIGN KEY (userID) REFERENCES user(userID),
	FOREIGN KEY (videoID) REFERENCES video(videoID)
)
ENGINE=INNODB;

CREATE TABLE event
(
	eventID INT AUTO_INCREMENT,
	adminID INT NOT NULL,
	title VARCHAR(256),
	description LONGTEXT NOT NULL,
	organizer VARCHAR(256) NOT NULL,
	email VARCHAR(256) NOT NULL,
	school VARCHAR(256) NOT NULL,
	link LONGTEXT NOT NULL,
	beginDate DATE NOT NULL,
	startTime TIME NOT NULL,
	endTime TIME NOT NULL,
	image VARCHAR(256) NOT NULL,
	PRIMARY KEY(eventID),
	FOREIGN KEY (adminID) REFERENCES user(userID)
)
ENGINE=INNODB;


--------------------------------------------------------------------------------------
INSERT INTO user (fname, lname, email, banned, admin)
VALUES ('Kyle', 'Combs', 'kycombs@iu.edu', 0, 0);

$title = mysqli_escape_string($conn, $_POST["title"]);
$description = mysqli_escape_string($conn,$_POST["description"]);
$organizer = $_POST["organizer"];
$email = $_POST["email"];
$school = $_POST["school"];
$link = $_POST["link"];

$beginDate = $_POST["beginDate"];
$endDate = $_POST["endDate"];

$newBeginDate = date('Y-m-d', strtotime($beginDate));
$newEndDate = date('Y-m-d', strtotime($endDate));

$startTime = $_POST["startTime"];
$newStartTime = date("H:i:s", strtotime($startTime));

$endTime = $_POST["endTime"];
$newEndTime = date("H:i:s", strtotime($endTime));

$user = (int) $_POST["user"];

$date = date('Y-m-d');