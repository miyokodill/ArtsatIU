<?php
//git pull origin master to get most recent code 
//Make changes and save
//cd into team 28 folder
//type git status
//type git add
//type git commit -m "Changes you made here"
//git push origin allieBranch  --> pushes to your branch on github
session_destroy();
$error = $_GET["error"];
$errorMsg;
if($error){
    $errorMsg = "That account does not exist";
}
if($_GET["err"]){
    $errorMsg = "Authorization Fail: Your account must match your IU Login Authentication";
}
if($_GET["err2"]){
    $errorMsg = "All input fields must be filled in";
}
?>
<!DOCTYPE HTML>
<html lang="en" class="">
<head>
	<meta charset="UTF-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<title>Arts@IU</title>

    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Fonts -->
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-regular.woff" rel="preload" type="font/woff2">
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-bold.woff" rel="preload" type="font/woff2">
    <link rel="preconnect" href="https://fonts.iu.edu" crossorigin="">
    <link rel="dns-prefetch" href="https://fonts.iu.edu">
    <link rel="stylesheet" type="text/css" href="//fonts.iu.edu/style.css?family=BentonSans:regular,bold|BentonSansCond:regular,bold|GeorgiaPro:regular|BentonSansLight:regular">
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">

    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="//assets.iu.edu/web/3.2.x/css/iu-framework.min.css?2020-12-03-2">
    <link rel="stylesheet" href="//assets.iu.edu/brand/3.2.x/brand.min.css?2020-12-03">
    <link rel="stylesheet" href="//assets.iu.edu/search/3.2.x/search.min.css?2020-12-03">

    <link href="//www.iu.edu/favicon.ico" rel="icon" />
    <link href="//www.iu.edu/favicon.ico" rel="shortcut icon" />
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/element/a57bc5975bc720b0/default+en.css">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/style/look/v4/default.css">

    <!-- Include Stylesheets -->
    <link href="brand.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/brand2.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/index.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="https://assets.iu.edu/favicon.ico" rel="shortcut icon" type="image/x-icon">

    <link href="./css/loginForm.css" rel="shortcut icon" type="image/x-icon">

    <style>

        body {
            margin: 0;
            padding: 0;
        }

    </style>

    <!-- Include Javascript -->

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://assets.iu.edu/search/3.2.x/search.js"></script>
    <script src="https://assets.iu.edu/web/3.2.x/js/iu-framework.min.js"></script>
    <script src="https://styleguide.iu.edu/_assets/js/site.js"></script>


    <script>

        // IUSearch.init({
        //     dynamicCSS: true,
        //     CX : {
        //         site: '014109358301568672738:jrgtuxfo2-0', // IU Admissions TEST
        //         all: '014109358301568672738:-tr9prjhqju' // IUPUI TEST
        //     }
        // });

    </script>

</head>

<body>

    
    <!-- Include Javascript -->
    <header>
        <!-- Navigation Skip -->
        <div id="skipnav">
            <ul>
            <li><a href="#content">Skip to Content</a></li>
            <li><a href="#nav-main">Skip to Main Navigation</a></li>
            <li><a href="#search">Skip to Search</a></li>
            </ul>
            <hr>
        </div>
        <!-- Branding Bar -->
        <div id="branding-bar" class="iu" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity" role="complementary" aria-labelledby="campus-name">
            <div class="row pad">
                    <img src="./images/trident-large.png" alt="" />
                    <p id="iu-campus">
                        <a href="@@url" title="Indiana University">
                            <span id="campus-name" class="show-on-desktop" itemprop="name">Indiana University</span>
                            <span class="show-on-tablet" itemprop="name">Indiana University</span>
                            <span class="show-on-mobile" itemprop="name">IU</span>
                        </a>
                    </p>
            </div>
        </div>
        <!-- Site Header -->
        <div class="site-header" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
            <div class="row pad">
                <h1><a class="title" href="#" itemprop="department">Arts@IU</a></h1>

            </div>
        </div>
        
    </header>

    <!-- No Section Nav -->
    <main class="no-section-nav">
        <div class="content-top">
            <div class="section breadcrumbs">
                <div class="row"><div class="layout">
                    <ul itemscope="itemscope" itemtype="http://schema.org/BreadcrumbList">
                    </ul>
                </div>
            </div>
        </div>
    
    <div class="section page-title bg-none">
        
        
        <!-- White Background -->
        <div id="main-content">
            <div class="extra-space horizontal-rule bg-none section" id="content">
                <div class="row">
                    <div class="layout">
                        <div class="text">
                          <article>
            <h1>IUArts Login</h1>
            <p style="font-size: 14px;">Arts@IU is an IU exclusive content sharing platform for fans of the arts. The website allows IU students to share their talents with the community through uploading videos. Arts@IU makes it easy to share talents, find friends, and engage in the IU arts community seamlessly online. </p>
            <h2>Login</h2>
            <?php echo '<p class="err" style="color:red;">' . $errorMsg . '</p>';?>
            <p>Please fill in your information to login.</p>
            <form action="./loginHandler.php" method="post">
                <div class="input-group">
                    <label>Email</label>
                    <input type="text" name="email" class="form-control">
                    <span class="help-block"><?php /*echo $email_err; */?></span>
                </div>    
                <!--<div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control">
                    <span class="help-block"><?php /*echo $password_err;*/ ?></span>
                </div>-->
                <!--<div class="input-group">
                    <label>First Name</label>
                    <input type="text" name="fname" class="form-control">
                    <span class="help-block"><?php /*echo $password_err; */?></span>
                </div>
                <div class="input-group">
                    <label>Last Name</label>
                    <input type="text" name="lname" class="form-control">
                    <span class="help-block"><?php /*echo $password_err; */?></span>
                </div>-->
                <div class="input-group">
                <button id="submit" name="submit" class="login-bttn">Submit</button>
                </div>
                <p>Don't have an account? <a href="./register.php">Sign up now</a>.</p>
            </form>
        </article>  


                <!-- LISTS -->

                <!-- Ordered Lists -->
                
                <!-- Unordered Lists -->
                <!-- Classes - "square", "circle", "no-bullet" -->
                
                <!-- Buttons -->
           

                <!-- Form Examples -->
      

            <!-- Gray Background -->

                    </div><!-- /.layout -->
                </div>
            </div>
            
        </div>
                            
      

                
    

        
    </main>

    <!-- Content Top -->

    <!-- Social Media Belt  -->
    <div class="section bg-mahogany bg-dark belt">
        <div class="row pad">
            <div class="one-half belt-nav">
                <ul class="inline">
                        <li><a href="https://www.iuauditorium.com/">IU Auditorium</a></li>
                        <li><a href="https://admissions.indiana.edu/life/arts.html">IU Arts</a></li>
                </ul>
            </div>
            <div class="one-half">
                <div class="invert border">
                    <ul class="social">
                        <li><a class="icon-twitter" href="#">Twitter</a></li>
                        <li><a class="icon-facebook" href="#">Facebook</a></li>
                        <li><a class="icon-instagram" href="#">Instagram</a></li>
                        <li><a class="icon-youtube" href="#/iu">YouTube</a></li>
                        <li><a class="icon-linkedin" href="#">LinkedIn</a></li>
                        <li><a class="icon-googleplus" href="#">Google Plus</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer  -->
	<footer id="footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
    <div class="row pad">
        <p class="signature">
            <a href="https://www.iu.edu" class="signature-link signature-img"><img src="images/iu-sig-formal.svg" alt="Indiana University" /></a>
        </p>

        <p class="copyright">
        <span class="line-break"><a href="https://accessibility.iu.edu/assistance" id="accessibility-link" title="Having trouble accessing this web page content? Please visit this page for assistance.">Accessibility</a> | <a href="/privacy" id="privacy-policy-link">Privacy Notice</a></span>
        <span class="hide-on-mobile"> | </span>
        <a href="https://www.iu.edu/copyright/index.html">Copyright</a> &#169; 2020 <span class="line-break-small">The Trustees of <a href="https://www.iu.edu/" itemprop="url"><span itemprop="name">Indiana University</span></a></span>
        </p>
    </div>
</footer>


</body>
</html>
