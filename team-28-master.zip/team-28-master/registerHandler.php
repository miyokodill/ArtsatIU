<?php

function clean($string)
{
    $string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.

    return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}
session_destroy();
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);


//Grabbing post vars and saving them to session so I can grab after authenticating through CAS
if (isset($_POST["submit"])) {
    echo 'YESSS';

    $fname = ucwords(trim(mysqli_real_escape_string($conn, $_POST["fname"])));
    $lname = ucwords(trim(mysqli_real_escape_string($conn, $_POST["lname"])));
    $email = strtolower(trim(mysqli_real_escape_string($conn, $_POST["email"])));

    if($fname == "" || $lname == "" || $email == ""){
        header("Location: ./register.php?err2=n");
        exit();
    }

   

    echo $fname . $lname . $email;

    //Creating tmp file to store posted info
    $filename = "tmpLogin.txt";
    if (file_exists($filename)) {
        unlink($filename);
    }
    $file = fopen($filename, "w");
    fwrite($file, "$fname,$lname,$email");
    fclose($file);
}


//Checking to see if we got the ticket
if ($_GET["ticket"]) {
    $ticket = $_GET["ticket"];
    echo $ticket . '<br>';

    $urlAuth2 = "https://idp.login.iu.edu/idp/profile/cas/serviceValidate";

    //https://stackoverflow.com/questions/5647461/how-do-i-send-a-post-request-with-php#:~:text=php%20%2F%2FThe%20url%20you,connection%20%24ch%20%3D%20curl_init()%3B%20%2F%2F

    $fields = [
        'ticket' => $ticket,
        'service' => "https://cgi.luddy.indiana.edu/~team28/team-28/registerHandler.php"
    ];
    $fields_string = http_build_query($fields);

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $urlAuth2);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    echo '<br>' . 'RESULT: ' . $result . '<br>';

    if ($result) {
        //Connect to DB

        //Executing connection

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
            header("Location: ./register.php?error=sql");
        }

        //Grab post variables from tmp text file
        $filename = "tmpLogin.txt";
        $file = fopen($filename, "r");
        $filesize = filesize($filename);
        $filetext = fread($file, $filesize);
        fclose($file);
        $explodeTxt = explode(",", $filetext);

        $fname = $explodeTxt[0];
        $lname = $explodeTxt[1];
        $email = $explodeTxt[2];

        $authEmail = "$result" . "@iu.edu";
        if (file_exists($filename)) {
            unlink($filename);
        }

        //Check to see if the user has registere
        $checkSQL = "SELECT * FROM user WHERE email='$email'";
        $checkSQLResult = mysqli_query($conn, $checkSQL);
        if (mysqli_num_rows($checkSQLResult) > 0) {
            header("Location: ./register.php?error=reg");
            echo 'EMAIL ALREADY IN DB';
        } else {
            echo "NNOOOOONNOJNONONO";


            $emailToUse = strval(trim(str_replace("@iu.edu", "", $email)));
            $result = clean($result);

            if (strpos($result, $emailToUse)) {
                echo 'h';
                //Insert user into DB
                $insertSQL = "INSERT INTO user(fname, lname, email, banned, admin) VALUES ('$fname', '$lname', '$email', 0, 0)";
                $insertResult = mysqli_query($conn, $insertSQL);

                $conn2 = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
                //Need to get user ID now
                $selectNewUserSQL = "SELECT * FROM user WHERE fname='$fname' AND lname='$lname' AND email='$email'";
                $selectNewUserResult = mysqli_query($conn2, $selectNewUserSQL);
                $selectArr = mysqli_fetch_assoc($selectNewUserResult);
                $uid = $selectArr["userID"];

                session_start();
                $_SESSION["fname"] = $fname;
                $_SESSION["lname"] = $lname;
                $_SESSION["email"] = $email;
                $_SESSION["uid"] = $uid;

                header("Location: ./profile.php?uid=$uid");
            } else {
                session_destroy();
                header("Location: ./register.php?err=authUserWrong");
                echo trim($emailToUse) . "<br>";
                echo trim($result) . "<br>";
                echo "EMAIL STRINGS " . strlen(trim($emailToUse)) . '<br>';
                echo "CAS STRINGS " . strlen(trim($result)) . '<br>';
                echo "STRINGS DONT MATCH";
            }
        }
    }
} else {
    header("Location: https://idp.login.iu.edu/idp/profile/cas/login?service=https://cgi.luddy.indiana.edu/~team28/team-28/registerHandler.php");
}
mysqli_close($conn);

