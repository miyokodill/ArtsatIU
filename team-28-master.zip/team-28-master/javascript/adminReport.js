(function () {
    if (window.addEventListener) {
        window.addEventListener('DOMContentLoaded', domReady, false);
    } else {
        window.attachEvent('onload', domReady);
    }
} ());

function domReady() {
    let bttn = document.getElementById("submit");
    bttn.disabled = true;
    function validate(){
        let description = document.getElementById("report").value;
        var yes = document.getElementById("radio-1");

        if(yes.checked && description !== ""){
            bttn.disabled =false;
        }
        else{
            bttn.disabled = true;
        }
    }
    window.addEventListener("click", validate);
    window.addEventListener("mouseup", validate);
    window.addEventListener("keyup", validate);
}
