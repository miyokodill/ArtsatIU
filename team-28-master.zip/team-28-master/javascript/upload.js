let thumb = document.querySelector("#thumbnail");


let bttn = document.querySelector(".submit");
bttn.style.backgroundColor ="gray";
bttn.disabled = true;
let vidContent;
let thumbContent


function validate(){
    let allFilled = true;

    //grabbing all values from inputs
    let title = document.querySelector("#title").value;
    let description = document.querySelector("#description").value;
    let thumbnail = document.querySelector("#thumbnail").files[0];
    let video = document.querySelector("#video").files[0];
    let price = document.querySelector("#price").value;
  
    vidContent = document.querySelector("#video").value;
    thumbContent = document.querySelector("#thumbnail").value;

    

    let categoryRadios = document.getElementsByName("category");
    let categorySelected = "";

    for (let i = 0; i < categoryRadios.length; i++){
        if (categoryRadios[i].checked){
            categorySelected = categoryRadios[i].value;
        }
    }

    if(title !== "" && description !== "" && vidContent !== "" && thumbContent !== "" && price !== "" && categorySelected !== ""){
        console.log("ALL FIELDS ARE FILLED IN, BUTTON ENABLED");
        console.log("VID " + vidContent);
        console.log("THUMB " + thumbContent);
        bttn.disabled = false;
        bttn.style.backgroundColor = "#990000";
    }
    else{
        bttn.disabled = true;
        bttn.style.backgroundColor = "gray";
    }
}





//Grabbing video input and limiting files user can select.
let video = document.querySelector("#video");
video.accept = "video/*";


//Validating user uploading proper image file whenever user selects file
thumb.onchange = function(e){
    let currThumb = document.querySelector("#thumbnail");

    let file = currThumb.files[0];

    if(file && file['type'].split('/')[0] === 'image'){
        console.log("proper image uploaded");
        validate();
    }
    else{
        alert("You must upload a PNG, JPG, or JPEG");
        currThumb.value = "";
        bttn.disabled = true;
        bttn.style.backgroundColor="gray";
    }
};

//Validating user uploads proper video file. 
video.onchange = function(e){
    let currVid = document.querySelector("#video");

    let file = currVid.files[0];

    if(file && file['type'].split('/')[0] === 'video'){
        console.log("Video!");
        validate();
    }
    else{
        alert("You must upload a video");
        currVid.value = "";
        file = "";
        bttn.disabled = true;
        bttn.style.backgroundColor="gray";
    } 
};


window.addEventListener("keyup", validate);
window.addEventListener("click", validate);
window.addEventListener("mouseup", validate);





