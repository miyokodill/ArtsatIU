let bttn = document.querySelector(".submit");
bttn.style.backgroundColor ="gray";
bttn.disabled = true;

let profilePic = document.querySelector("#pic");

function validate(){
    let allFilled = true;
    let gender = document.querySelector("#gender");
    let pronouns = document.querySelector("#pronouns");
    let year = document.querySelector("#year");
    let major = document.querySelector("#major");
    let interests = document.querySelector("#interests");
    let bio = document.querySelector("#bio");
    let pic = document.querySelector("#pic");

    if(gender.value !== "" && pronouns.value !== "" && year.value !== "" && major.value !== "" && interests.value !== "" && bio.value !== ""){
        allFilled = true;
    }else{
        bttn.disabled = true;
        bttn.style.backgroundColor = "gray";
        allFilled = false;
    }
    let file = pic.files[0];

    if(file && file['type'].split('/')[0] === 'image'){
        console.log("proper image uploaded");
    }else{
        allFilled = false;
    }

    if(allFilled == true){
        console.log("ALL FIELDS ARE FILLED IN, BUTTON ENABLED");
        bttn.disabled = false;
        bttn.style.backgroundColor = "#990000"
    }else{
        bttn.disabled = true;
        bttn.style.backgroundColor = "gray";
        allFilled = false;
    }


}

profilePic.onchange = function(e){
    let currThumb = document.querySelector("#pic");

    let file = currThumb.files[0];

    if(file && file['type'].split('/')[0] === 'image'){
        console.log("proper image uploaded");
        validate();
    }
    else{
        alert("You must upload a PNG, JPG, or JPEG");
        currThumb.value = "";
        bttn.disabled = true;
        bttn.style.backgroundColor="gray";
    }
};

window.addEventListener("keyup", validate);
window.addEventListener("click", validate);
window.addEventListener("mouseup", validate);