/*function sendMessage(){
    $.ajax({
        type: "POST",
        url: "../php/chat.php",
        data: {"message": message, "senderID": senderID, "receiverID": receiverID},
        datatype: "json"
    });
}




let bttn = document.querySelector("#bttn");

bttn.addEventListener("click", sendMessage);

let message = document.querySelector("#text");
let senderID = 1;
let receiverID = 2*/