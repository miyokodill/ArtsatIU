let bttn = document.querySelector(".submit");
bttn.style.backgroundColor ="gray";
bttn.disabled = true;

let profilePic = document.querySelector("#pic");

function validate(){
    let allFilled = true;
    let title = document.querySelector("#title");
    let description = document.querySelector("#description");

    if(title.value !== "" && description.value !== ""){
        allFilled = true;
    }else{
        allFilled = false;
    }


    if(allFilled == true){
        console.log("ALL FIELDS ARE FILLED IN, BUTTON ENABLED");
        bttn.disabled = false;
        bttn.style.backgroundColor = "#990000"
    }else{
        bttn.disabled = true;
        bttn.style.backgroundColor = "gray";
        allFilled = false;
    }


}


window.addEventListener("keyup", validate);
window.addEventListener("click", validate);
window.addEventListener("mouseup", validate);