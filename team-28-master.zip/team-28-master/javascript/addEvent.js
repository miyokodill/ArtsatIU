let thumb = document.querySelector("#thumbnail");


let bttn = document.querySelector(".submit");
bttn.style.backgroundColor ="gray";
bttn.disabled = true;


function validate(){
    let allFilled = true;

    //grabbing all values from inputs
    let title = document.querySelector("#title").value;
    let description = document.querySelector("#description").value;
    let thumbnail = document.querySelector("#thumbnail").files[0];
    let organizer = document.querySelector("#organizer").value;
    let email = document.querySelector("#email").value;
    let school = document.querySelector("#school").value;
    let link = document.querySelector("#link").value;
    let eventDate = document.querySelector("#beginDate").value;
    let startTime = document.querySelector("#startTime").value;
    let endTime = document.querySelector("#endTime").value;

    

    if(title !== "" && description !== "" && thumbnail !== "" && organizer !== "" && email !== "" && school !== "" && link !== "" && eventDate !== "" && startTime !== "" && endTime !== ""){
        console.log("ALL FIELDS ARE FILLED IN, BUTTON ENABLED");
        bttn.disabled = false;
        bttn.style.backgroundColor = "#990000";
    }
    else{
        bttn.disabled = true;
        bttn.style.backgroundColor = "gray";
    }
}


//Validating user uploading proper image file whenever user selects file
thumb.onchange = function(e){
    let currThumb = document.querySelector("#thumbnail");

    let file = currThumb.files[0];

    if(file && file['type'].split('/')[0] === 'image'){
        console.log("proper image uploaded");
    }
    else{
        alert("You must upload a PNG, JPG, or JPEG");
        currThumb.value = "";
        bttn.disabled = true;
        bttn.style.backgroundColor="gray";
    }
};



window.addEventListener("keyup", validate);
window.addEventListener("click", validate);
window.addEventListener("mouseup", validate);
