//https://www.w3schools.com/howto/howto_js_filter_lists.asp
function myFunction() {
    // Declare variables
    var input, filter, users, user, a, i, txtValue;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    users = document.querySelector(".users");
    user = users.getElementsByTagName('div');
  
    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < user.length; i++) {
      a = user[i].getElementsByTagName("a")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        user[i].style.display = "";
      } else {
        user[i].style.display = "none";
      }
    }
  }
