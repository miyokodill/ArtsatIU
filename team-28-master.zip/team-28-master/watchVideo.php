<?php
$date = date('Y-m-d');

//DANIEL TODO:
//In the more videos query. ALTER video select queries to include AND launchDate < '$date'
//Example
//"SELECT * FROM video WHERE category='music' AND launchDate<='$date' ORDER BY rand()";  Comment from Daniel - Line 89
function formatDate($date)
{
    return date('m/d/Y', strtotime($date));
}
function formatTime($time)
{
    return date('g:i a', strtotime($time));
}
//Checking if user is logged in
session_start();
//$_SESSION["uid"] = 8;
if (!isset($_SESSION["uid"])) {
    header("Location: ./loginForm.php");
}



if ($_GET["vid"]) {
    $DB_HOST = 'db.luddy.indiana.edu';
    $DB_NAME = 'i494f20_team28';
    $DB_USER = 'i494f20_team28';
    $DB_PWD = 'my+sql=i494f20_team28';

    $loggedInUser = (int)$_SESSION["uid"];
    $vid = (int) $_GET["vid"];

    //Connecting to database
    $conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
    //Check DB connection
    //In the future will want session var to take back to prev location
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        header("Location: ../index.php?error=sql");
    }
    //Checking to see if user has already viewed video
    $selectWatchCount1 = "SELECT userID, videoID FROM view WHERE userID=$loggedInUser and videoID=$vid";
    $selectWatchRes1 = mysqli_query($conn, $selectWatchCount1);
    if (mysqli_num_rows($selectWatchRes1) == 0) {
        //if user has not viewed video, then add a view
        //Updating view with a new view because user clicked on video
        $insertWatchSQL = "INSERT INTO view (userID, videoID) VALUES ($loggedInUser, $vid)";
        mysqli_query($conn, $insertWatchSQL);
    }

    //Getting number of views
    $selectWatchCount = "SELECT COUNT(userID) AS views FROM view WHERE videoID=$vid";
    $selectWatchRes = mysqli_query($conn, $selectWatchCount);

    $selectWatchAssoc = mysqli_fetch_assoc($selectWatchRes);
    $views = (int)$selectWatchAssoc["views"];



    //Check admin status
    $adminStatus = "SELECT * FROM user WHERE userID=$loggedInUser";
    $adminResult = mysqli_query($conn, $adminStatus);
    $adminArray = mysqli_fetch_assoc($adminResult);
    $admin = (int) $adminArray["admin"];

    //Query and data retrieval for video user clicked on
    $sql = "SELECT title, vidDescription, uploadDate, ticketPrice, ownerID, vidLocation, launchDate FROM video WHERE videoID=$vid";
    $result = mysqli_query($conn, $sql);


    //Retrieving info about the vid 
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $vidSrc = $row["vidLocation"];
        $title = $row["title"];
        $vidDescription = $row["vidDescription"];
        $ownerID = (int)$row["ownerID"];
        $uploadDate = $row["uploadDate"];
        $price = (int) $row["ticketPrice"];

        //preventing user who does not own video from accessing video prior to launch date.
        if ($row["launchDate"] > $date && $loggedInUser != $ownerID) {
            header("Location:./index.php?error=getVid");
            exit();
        }

        //Checking to see if a video requires payment
        //If user owns a vid, then they don't have to pay for it.
        //if ($loggedInUser != $ownerID){
        if ($price > 0 & (int)$loggedInUser != (int)$ownerID) {
            if ($admin != 1) {
                //If vid has price, then we need to check if user has paid for video
                //Query to check if there is a record of user paying for vid
                $paySQL = "SELECT buyerID, videoID FROM ticketSale WHERE buyerID = $loggedInUser AND videoID=$vid";
                $payResult = mysqli_query($conn, $paySQL);
                //Seeing if anything was returned from DB
                $payRows = mysqli_num_rows($payResult);
                if ($payRows == 0) {
                    //If payRows is 0, that means user hasn't paid for vid yet
                    header("Location: ./payment.php?vid=$vid");
                }
            }
        }
        //}
    } else {
        header("Location: ./index.php?error=getVid");
    }

    //Query to get creator name and info for commenting
    $userQuery = "SELECT fname, lname FROM user WHERE userID=$ownerID";
    $userResult = mysqli_query($conn, $userQuery);
    $userRow = mysqli_fetch_assoc($userResult);
    $fname = $userRow["fname"];
    $lname = $userRow["lname"];


    //Query to retrieve more videos from this user
    $moreVideosQuery = "SELECT videoID, title, thumbnailLocation, ticketPrice, uploadDate FROM video WHERE ownerID=$ownerID AND launchDate<='$date'";
    $moreVideoResult = mysqli_query($conn, $moreVideosQuery);

    //$launchDate = "SELECT * FROM video WHERE category='music' AND launchDate<='$date' ORDER BY rand()";

    $likesSQL = "SELECT COUNT(userID) AS count FROM likes WHERE videoID=$vid";
    $likesResult = mysqli_query($conn, $likesSQL);
    $likesArray = mysqli_fetch_assoc($likesResult);
    $likesCount = $likesArray["count"];



    //Checking to see whether user has liked video or not
    //This will tell us whether to show the like or unlike button
    $likeQuery = "SELECT * FROM likes WHERE userID=$loggedInUser AND videoID=$vid";
    $likeResult = mysqli_query($conn, $likeQuery);
    $liked = false;
    if (mysqli_num_rows($likeResult) > 0) {
        $liked = true;
    }

    $reportQuery = "SELECT * FROM report WHERE reporterID=$loggedInUser AND videoID=$vid";
    $reportResult = mysqli_query($conn, $reportQuery);
    $reported = false;
    if (mysqli_num_rows($reportResult) > 0) {
        $reported = true;
    }
    //This determines whether or not to display admin tab on nav
    $adminSelect = "SELECT * FROM user WHERE userID=$loggedInUser";
    $adminResult = mysqli_query($conn, $adminSelect);
    $adminAssoc = mysqli_fetch_assoc($adminResult);
    $adminInfo = (int)$adminAssoc["admin"];
    $admin = false;

    if ($adminInfo == 1) {
        $admin = true;
    }


    //Want to send user back to previous page with Sessions 
} else {
    header("Location: ./profile.php?uid=$loggedInUser");
}

?>

<!DOCTYPE HTML>
<html lang="en" class="">

<head>
    <meta charset="UTF-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Arts@IU</title>

    <meta content="" name="keywords" />
    <meta content="" name="description" />

    <!-- Fonts -->
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-regular.woff" rel="preload" type="font/woff2">
    <link as="font" crossorigin="" href="https://fonts.iu.edu/fonts/benton-sans-bold.woff" rel="preload" type="font/woff2">
    <link rel="preconnect" href="https://fonts.iu.edu" crossorigin="">
    <link rel="dns-prefetch" href="https://fonts.iu.edu">
    <link rel="stylesheet" type="text/css" href="//fonts.iu.edu/style.css?family=BentonSans:regular,bold|BentonSansCond:regular,bold|GeorgiaPro:regular|BentonSansLight:regular">
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- CSS Stylesheets -->
    <link rel="stylesheet" href="//assets.iu.edu/web/3.2.x/css/iu-framework.min.css?2020-12-03-2">
    <link rel="stylesheet" href="//assets.iu.edu/brand/3.2.x/brand.min.css?2020-12-03">
    <link rel="stylesheet" href="//assets.iu.edu/search/3.2.x/search.min.css?2020-12-03">

    <link href="//www.iu.edu/favicon.ico" rel="icon" />
    <link href="//www.iu.edu/favicon.ico" rel="shortcut icon" />
    <link rel="stylesheet" href="//assets.iu.edu/web/fonts/icon-font.css" media="screen">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/element/a57bc5975bc720b0/default+en.css">
    <link type="text/css" rel="stylesheet" href="https://www.google.com/cse/static/style/look/v4/default.css">

    <!-- Include Stylesheets -->
    <link href="brand.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/brand2.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="css/index.css" rel="stylesheet" type="text/css" media="screen" />
    <link href="https://assets.iu.edu/favicon.ico" rel="shortcut icon" type="image/x-icon">
    <link rel="stylesheet" href="./css/watchVideo.css">

    <style>
        body {
            margin: 0;
            padding: 0;
        }

        .comments {
            height: 650px;
            width: 100%;
            overflow: scroll;
        }

        .vidW {
            width: 100%;
        }

        .beneathVid a {
            color: #45382B;
        }

        .beneathVid a:hover {
            color: #990000;
        }

        label {
            color: #45382B;
        }

        .innerComment p {
            color: #45382B;
            text-decoration: none;
        }

        .innerComment p:hover {
            color: #990000;
        }

        .innerComment a {
            text-decoration: none;
            color: #45382B;
        }

        .belowCreatedBy {
            margin-right: 15px;
        }

        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            /* Stay in place */
            z-index: 1;
            /* Sit on top */
            left: 0;
            top: 0;
            width: 100%;
            /* Full width */
            height: 100%;
            /* Full height */
            overflow: auto;
            /* Enable scroll if needed */
            background-color: rgb(0, 0, 0);
            /* Fallback color */
            background-color: rgba(0, 0, 0, 0.4);
            /* Black w/ opacity */
        }

        /* Modal Content/Box */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 70%;
            /* Could be more or less, depending on screen size */
        }

        .modalInner {
            display: flex;
            flex-flow: column wrap;
            justify-content: center;
            align-items: center;
            padding-top: 15px;
            padding-left: 10px;
            padding-right: 10px;
        }

        .modal-content img {
            height: 100px;
        }


        /* The Close Button */
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
    </style>

    <!-- Include Javascript -->

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://assets.iu.edu/search/3.2.x/search.js"></script>
    <script src="https://assets.iu.edu/web/3.2.x/js/iu-framework.min.js"></script>
    <script src="https://styleguide.iu.edu/_assets/js/site.js"></script>


    <script>

    </script>

</head>

<body class="mahogany no-banner has-page-title landmarks">

    <!-- Include Javascript -->
    <header id="header">
        <!-- Navigation Skip -->
        <div id="skipnav">
            <ul>
                <li><a href="#content">Skip to Content</a></li>
                <li><a href="#nav-main">Skip to Main Navigation</a></li>
                <li><a href="#search">Skip to Search</a></li>
            </ul>
            <hr>
        </div>
        <!-- Branding Bar -->
        <div id="branding-bar" class="iu" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity" role="complementary" aria-labelledby="campus-name">
            <div class="row pad">
                <img src="images/trident-large.png" alt="" />
                <p id="iu-campus">
                    <a href="@@url" title="Indiana University">
                        <span id="campus-name" class="show-on-desktop" itemprop="name">Indiana University</span>
                        <span class="show-on-tablet" itemprop="name">Indiana University</span>
                        <span class="show-on-mobile" itemprop="name">IU</span>
                    </a>
                </p>
            </div>
        </div>
        <div id="offCanvas" class="hide-for-large" role="navigation" aria-label="Mobile">
            <button class="menu-toggle button hide-for-large" data-toggle="iu-menu">Menu</button>
            <div id="iu-menu" class="off-canvas position-right off-canvas-items" data-off-canvas="" data-position="right">
                <div class="mobile off-canvas-list" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
                    <ul>
                        <li class=""><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                        <li class="has-children">
                            <a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                            <ul class="children">
                                <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                                <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                                <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                                <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                                <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                                <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                                <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                                <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                            </ul>
                        </li>
                        <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                        <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                        <?php echo '<li><a href="./profile.php' . "?uid=$loggedInUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                        <li><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                        <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                        <?php
                        if ($admin == true) {
                            echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                        }
                        ?>

                </div>
            </div>
        </div>
        <!-- Site Header -->
        <div class="site-header" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
            <div class="row pad">
                <h1><a class="title" href="index.php" itemprop="department">Arts@IU</a></h1>
            </div>
        </div>
        <!-- Nav Bar -->
        <div id="nav-main-sticky-wrapper" class="sticky-nav" style="height: 54px;">
            <nav aria-label="Main" id="nav-main" role="navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" class="main show-for-large dropdown" style="width: 1428px;">
                <ul class="row pad">
                    <li class="show-on-sticky home"><a href="./index.php" aria-label="Home">Home</a></li>
                    <li class="first"><a href="./index.php" itemprop="url"><span itemprop="name">Home</span></a></li>
                    <li><a href="#" itemprop="url"><span itemprop="name">Categories</span></a>
                        <ul class="children">
                            <li><a href="displayVideos.php?category=music" itemprop="url"><span itemprop="name">Music</span></a></li>
                            <li><a href="displayVideos.php?category=dance" itemprop="url"><span itemprop="name">Dances</span></a></li>
                            <li><a href="displayVideos.php?category=theater" itemprop="url"><span itemprop="name">Theatre</span></a></li>
                            <li><a href="displayVideos.php?category=art" itemprop="url"><span itemprop="name">Graphic Arts</span></a></li>
                            <li><a href="displayVideos.php?category=comedy" itemprop="url"><span itemprop="name">Comedy</span></a></li>
                            <li><a href="displayVideos.php?category=photography" itemprop="url"><span itemprop="name">Photography</span></a></li>
                            <li><a href="displayVideos.php?category=follows" itemprop="url"><span itemprop="name">Users You Follow</span></a></li>
                            <li><a href="displayVideos.php?category=free" itemprop="url"><span itemprop="name">Free</span></a></li>
                        </ul>
                    </li>
                    <li><a href="./upload.php" itemprop="url"><span itemprop="name">Upload</span></a></li>
                    <li><a href="./events.php" itemprop="url"><span itemprop="name">Events</span></a></li>
                    <?php echo '<li><a href="./profile.php' . "?uid=$loggedInUser" . '" itemprop="url"><span itemprop="name">Profile</span></a></li>'; ?>
                    <li><a href="./users.php" itemprop="url"><span itemprop="name">Users</span></a></li>
                    <li><a href="./displayMessage.php" itemprop="url"><span itemprop="name">Messages</span></a></li>
                    <?php
                    if ($admin == true) {
                        echo '<li><a href="./adminHome.php" itemprop="url"<span itemprop="name">Admin</span></a></li>';
                    }

                    ?>
                    <li><a class="login-bttn" href="./php/logout.php" itemprop="url"><span itemprop="name">Logout</span></a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- No Section Nav -->
    <main class="no-section-nav">

        <!-- White Background -->
        <div id="main-content">
            <div class="breakout bg-none section" id="content">
                <div class="row">
                    <div class="layout">
                        <!-- Main Video -->
                        <div class="grid two-thirds">
                            <div class="grid-item" style="height: 296px;">
                                <div class="content">
                                    <div class="home vid">
                                        <h2><?php echo $title; ?></h2>
                                        <video class="vidW" width="100%" height="322px" controls>
                                            <?php
                                            echo '<source src="../videos/' . $vidSrc . '" type="video/mp4">';
                                            ?>
                                        </video>
                                        <div class="beneathVid">
                                            <p><strong>Created By:</strong> <?php echo '<a href="./profile.php?uid=' . $ownerID . '">' . $fname . ' ' . $lname . '</a>'; ?></p>
                                            <p><?php echo $likesCount; ?> likes</p>
                                            <p><?php echo $views; ?> views</p>
                                        </div>
                                        <!--Like button here -->
                                        <div class="belowCreatedBy">
                                            <?php
                                            if ($liked) {
                                                echo '
                                                <form class="likeForm" action="./php/unlike.php" method="post">
                                                <div class="liking">
                                                    <button type="submit"><i class="fa fa-thumbs-down"></i></button>
                                                    <label>Unlike Video</label>
                                                    
                                                </div>';
                                                echo '<input type="hidden" name="vid" value="' . $vid . '" />';

                                                echo '</form>';
                                            } else {
                                                echo '
                                                <form class="likeForm" action="./php/like.php" method="post">
                                                <div class="liking">
                                                    <button type="submit"><i class="fa fa-thumbs-up"></i></button>
                                                    <label>Like Video</label>
                                                    
                                                </div>';
                                                echo '<input type="hidden" name="vid" value="' . $vid . '" />';

                                                echo '</form>';
                                            }

                                            ?>

                                            <?php
                                            if ($loggedInUser == $ownerID) {
                                                echo '<form action="./editVideo.php" method="post">';
                                                echo '<input type="hidden" name="vid" value="' . $vid . '" />';
                                                echo '<button type="submit" class="button rvt-button--danger" id="editBttn">Edit Video</button>';
                                                echo '</form>';
                                            }
                                            if ($loggedInUser == $ownerID && $price == 0) {
                                                echo '<form action="./php/userDeleteVid.php" method="post">';
                                                echo '<input type="hidden" name="vid" value="' . $vid . '" />';
                                                echo '<button type="submit" class="button rvt-button--danger">Delete Video</button>';
                                                echo '</form>';
                                            }
                                            ?>
                                        </div>
                                        <div class="aboveDescrip">
                                            <?php
                                            //See if the user is an admin
                                            if ($admin == 1) {
                                                //
                                                //Only allow a video to be pushed to home page if it is a free video
                                                if ($price == 0) {
                                                    echo '<form action="./adminPush.php" method="post">';
                                                    echo '<button class="button rvt-button--success">Push</button>';
                                                    echo '<input type="hidden" name="vid" value="' . $vid . '" />';
                                                    echo '</form>';
                                                    //$_POST["vid"]
                                                }
                                            }
                                            if ($admin == 1 && $ownerID != $loggedInUser) {
                                                echo '<form action="./adminDelete.php" method="post">';
                                                echo '<button class="button rvt-button--danger">Admin Delete</button>';
                                                echo '<input type="hidden" name="vid" value="' . $vid . '" />';
                                                echo '</form>';
                                            }
                                            if ($reported == false) {
                                                echo '
                                                    <form action="./php/report.php" method="post">
                                                        <input type="hidden" name="video" value="' .  $vid . '"/>';
                                                echo '
                                                        <button class="button" type="submit" name="submit">Report Video</button>
                                                    </form>';
                                            }
                                            ?>

                                        </div>
                                        <div class="description">
                                            <p><strong>Description:</strong></p>
                                            <p class="pad"><?php echo $vidDescription; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Comments -->
                        <div class="grid one-third">
                            <div class="grid-item" style="height: 296px;">
                                <div class="feature">
                                    <div class="content">
                                        <div class="comments">
                                            <h3 id="commentHeader">Comments</h3>
                                            <div class="commentCont">

                                                <?php
                                                $commentSQL = "SELECT * FROM comments WHERE videoID=$vid ORDER BY date DESC, time DESC";
                                                $commentResult = mysqli_query($conn, $commentSQL);
                                                while ($row = mysqli_fetch_assoc($commentResult)) {
                                                    $commenterID = (int)$row["userID"];

                                                    $userSQL = "SELECT * FROM user WHERE userID=$commenterID";
                                                    $userSQLResult = mysqli_query($conn, $userSQL);
                                                    $userSQLArray = mysqli_fetch_assoc($userSQLResult);

                                                    $fname = $userSQLArray["fname"];
                                                    $lname = $userSQLArray["lname"];

                                                    $userProfileSQL = "SELECT * FROM user_profile WHERE userID=$commenterID";
                                                    $userProfileResult = mysqli_query($conn, $userProfileSQL);
                                                    $userProfileArray = mysqli_fetch_assoc($userProfileResult);
                                                    $profilePic = $userProfileArray["profilePic"];

                                                    echo '<div class="comment">';
                                                    echo '<div class="innerComment">';
                                                    if (is_null($profilePic)) {
                                                        echo '<img src="./images/avatar.png" alt="profilePic">';
                                                    } else {
                                                        echo '<img src="../profilePics/' . $profilePic . '" alt="profilePic">';
                                                    }
                                                    echo '<a href="./profile.php' . "?uid=$commenterID" . '"><p style="margin-right: 10px;width:max-content;">' . $fname . ' ' . $lname . '</p></a>';
                                                    echo '<p style="margin-right: 10px;font-size:14px;">' . formatDate($row["date"]) . '<br>' . formatTime($row["time"]) . '</p>';
                                                    echo '</div>';
                                                    echo '<div class="content">';
                                                    echo '<p>' . $row["content"] . '</p>';
                                                    echo '</div>';
                                                    echo '</div>';
                                                }
                                                ?>
                                            </div>
                                            <form class="commentForm" method="post" action="./php/comment.php">
                                                <input type="hidden" name="commenterID" value=<?php echo '"' . $loggedInUser . '"'; ?>>
                                                <input type="hidden" name="videoID" value=<?php echo '"' . $vid . '"'; ?>>
                                                <input class="box" name="comment" id="text" type="text">
                                                <button type="submit" name="submit" id="bttn">Comment<img src="./images/send.png"></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.layout -->
                </div>
            </div>

            <div class="breakout bg-none section" id="content">
                <div class="row">
                    <div class="layout">
                        <!-- Main Video -->
                        <h3 id="moreVidsHeader">More Videos from this User</h3>
                        <div class="moreVids">
                            <?php

                            while ($row = mysqli_fetch_assoc($moreVideoResult)) {
                                if ($row["videoID"] != $vid) {
                                    $fname = $row["fname"];
                                    $lname = $row["lname"];
                                    echo '<a href="./watchVideo.php?vid=' . $row["videoID"] . '">';
                                    echo '<div class="new">';
                                    echo '<img src="../thumbnails/' . $row["thumbnailLocation"] . '" alt="img">';
                                    echo '<div class="newVid">';
                                    echo '<div class="newVidText">';
                                    echo '<p>' . $row["title"] . '</p>';
                                    echo '<p class="date">Published on: ' . formatDate($row["uploadDate"]) . '</p>';
                                    echo '</div>';
                                    echo '<p>' . $fname . ' ' . $lname . '</p>';
                                    if ($row["ticketPrice"] > 0) {
                                        echo '<p>Price: $' . $row["ticketPrice"] . '</p>';
                                    }
                                    echo '</div>';
                                    echo '</div>';
                                    echo '</a>';
                                }
                            }
                            ?>
                        </div>
                    </div><!-- /.layout -->
                </div>
            </div>

    </main>

    <!-- Social Media Belt  -->
    <div class="section bg-mahogany bg-dark belt">
        <div class="row pad">
            <div class="one-half belt-nav">
                <ul class="inline">
                    <li><a href="https://www.iuauditorium.com/">IU Auditorium</a></li>
                    <li><a href="https://admissions.indiana.edu/life/arts.html">IU Arts</a></li>
                </ul>
            </div>
            <div class="one-half">
                <div class="invert border">
                    <ul class="social">
                        <li><a class="icon-twitter" href="#">Twitter</a></li>
                        <li><a class="icon-facebook" href="#">Facebook</a></li>
                        <li><a class="icon-instagram" href="#">Instagram</a></li>
                        <li><a class="icon-youtube" href="#/iu">YouTube</a></li>
                        <li><a class="icon-linkedin" href="#">LinkedIn</a></li>
                        <li><a class="icon-googleplus" href="#">Google Plus</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer  -->
    <footer id="footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/CollegeOrUniversity">
        <div class="row pad">
            <p class="signature">
                <a href="https://www.iu.edu" class="signature-link signature-img"><img src="images/iu-sig-formal.svg" alt="Indiana University" /></a>
            </p>

            <p class="copyright">
                <span class="line-break"><a href="https://accessibility.iu.edu/assistance" id="accessibility-link" title="Having trouble accessing this web page content? Please visit this page for assistance.">Accessibility</a> | <a href="/privacy" id="privacy-policy-link">Privacy Notice</a></span>
                <span class="hide-on-mobile"> | </span>
                <a href="https://www.iu.edu/copyright/index.html">Copyright</a> &#169; 2020 <span class="line-break-small">The Trustees of <a href="https://www.iu.edu/" itemprop="url"><span itemprop="name">Indiana University</span></a></span>
            </p>
        </div>
    </footer>
    <div id="myModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="modalInner">
                <img src="./images/trident-large.png">
                <p class="modalText">You have tried to access a file on the website in an improper way and have been redirected to the home page.</p>
            </div>
        </div>

    </div>
    <script>
        let url_string = window.location.href;
        let url = new URL(url_string);
        if (url.searchParams.get("report") == "1" || url.searchParams.get("error") == "admin" || url.searchParams.get("error") == "getVid") {
            //alert("You have tried to access a page improperly and have been redirected to the home page");

            // Get the modal
            var modal = document.getElementById("myModal");

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks on the button, open the modal

            modal.style.display = "block";


            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
            if (url.searchParams.get("report") == "1") {
                let text = document.querySelector(".modalText").innerHTML = "You have successfully reported this video.";
            }
            if (url.searchParams.get("error") == "getVid") {
                let text = document.querySelector(".modalText").innerHTML = "You have tried to watch a video that does not exist or has not launched yet and have been redirected to the home page.";
            }


        }
    </script>

    <?php mysqli_close($conn); ?>
</body>

</html>