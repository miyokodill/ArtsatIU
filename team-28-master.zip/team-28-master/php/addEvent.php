<?php
session_start();
if (isset($_SESSION["uid"])) {
    $senderID = (int) $_SESSION["uid"];
} else {
    header("Location: ../loginForm.php");
    exit();
}
//Making sure user is uploading via form.
if(isset($_POST["submit"])){
//DB Information
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php?error=sql");
    exit();
}

//POST info
$title = mysqli_escape_string($conn, $_POST["title"]);
$description = nl2br(htmlentities($_POST["description"] ,ENT_QUOTES,'UTF-8'));
$organizer = mysqli_escape_string($conn,$_POST["organizer"]);
$email = mysqli_escape_string($conn, $_POST["email"]);
$school = mysqli_escape_string($conn,$_POST["school"]);
$link = mysqli_escape_string($conn,$_POST["link"]);

$beginDate = $_POST["beginDate"];
$newBeginDate = date('Y-m-d', strtotime($beginDate));


$startTime = $_POST["startTime"];
$newStartTime = date("H:i:s", strtotime($startTime));

$endTime = $_POST["endTime"];
$newEndTime = date("H:i:s", strtotime($endTime));

$user = (int) $_POST["userID"];

$date = date('Y-m-d');


//DIRECTORY info
$thumbDir = "/u/team28/cgi-pub/events/";

//Building up unique thumbnail name
//Format is userID_Timestamp_filename
$thumbTemp = $_FILES["userfile"]["name"][0];
$newThumbName = $user . "_" . round(microtime(true)) . '_' . $thumbTemp;

//Uploading files with if condition to ensure files properly uploaded
//If uploading error, user is taken back to upload page
if (move_uploaded_file($_FILES["userfile"]["tmp_name"][0], $thumbDir . $newThumbName)){
    echo "THUMBNAIL has been uploaded to thumbnail directory";
}else{
    echo "Add Event Image Failed, please try again";
    header("Location: ../events.php?error=upload");
}


$thumbPath = $thumbDir . $newThumbName;


//SQL Insert Video Information
$sql = "INSERT INTO event (adminID,title,description,organizer,email,school,link,beginDate,startTime,endTime,image) VALUES($user,'$title','$description','$organizer','$email','$school','$link','$newBeginDate','$newStartTime','$newEndTime','$newThumbName')";


if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    header("Location: ../events.php?upload=success");
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  
mysqli_close($conn);




}else{
    echo "WRONG";
    header("Location: ../index.php?error=access");
    exit();
}
mysqli_close($conn);

?>