<?php
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
session_start();

if(!isset($_SESSION["uid"])){
    header("Location: ../loginForm.php");
    exit();
}

if (isset($_POST["submit"])) {
    $visitor = (int) $_POST["visitor"];
    $profile = (int) $_POST["profile"];

    //Connecting to database
    $conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);

    //Check DB connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        header("Location: ../profile.php?error=sql&uid=$profile");
    }
    //SQL to delete follower relationship
    $sql = "DELETE FROM user_followers WHERE followerID=$visitor AND followingID=$profile";
    //Executing query
    if (mysqli_query($conn, $sql)){
        echo "New record created successfully";
        header("Location: ../profile.php?unfollow=success&uid=$profile");
    }else{
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}else{
    header("Location: ../index.php?error=access");
}
mysqli_close($conn);