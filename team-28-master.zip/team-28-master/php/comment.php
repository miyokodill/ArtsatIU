<?php
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
//Checking to make sure user is logged in. 
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../login.php");
    exit();
}

//Grabbing POST data
$comment = $_POST["comment"];
$commenterID =  (int) $_POST["commenterID"];
$vidID = (int) $_POST["videoID"];
$date = date('Y-m-d');
$time = date("H:i:s");
//Checking to make sure user is accessing commenting the right way
if (!isset($_POST["submit"])){
    header("Location: ../index.php?error=access");
    exit();
}
//Connecting to DB
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../watchVideo.php?error=sql&vid=$vidID");
    exit();
}

//Executing insert query
$sql = "INSERT INTO comments(userID, videoID, date, time, content) VALUES ($commenterID, $vidID, '$date', '$time', '$comment')";
$sqlResult = mysqli_query($conn, $sql);

if($sqlResult){
    echo 'SUCCESS';
    header("Location: ../watchVideo.php?vid=$vidID&sql=success");
    exit();
}else{
    echo 'FAIL';
    header("Location: ../watchVideo.php?vid=$vidID&sql=fail");
    exit();



}
mysqli_close($conn);


?>