<?php
session_start();


//Check session to make sure user logged in
if (!isset($_SESSION["uid"])) {
    header("Location: ../loginForm.php");
    exit();
} else {
    $sessionUser = $_SESSION["uid"];
}

if(!isset($_POST["vid"])){
    header("Location: ../profile.php?uid=$sessionUser&error=access");
    exit();
}else{
    $vid = (int)$_POST["vid"];
}


//$launchDate = $_POST["reserve"];
//$newLaunchDate = date('Y-m-d', strtotime($launchDate));

//Checking to make sure user is editing their profile by comparing the profile they are editing to their logged in ID 

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../profile.php?uid=$sessionUser&error=sql");
    exit();
}
//Grabbing post information
$price = (int)$_POST["price"];
$category = $_POST["category"];
$description = mysqli_escape_string($conn,$_POST["description"]);
$title = mysqli_escape_string($conn,$_POST["title"]);

$updateSQL = "UPDATE video SET category='$category',title='$title',vidDescription='$description', ticketPrice=$price WHERE videoID=$vid";
//$updateSQLResult = mysqli_query($conn,$updateSQL);
//mysqli_close($conn);

if(mysqli_query($conn,$updateSQL)){
    header("Location: ../watchVideo.php?vid=$vid&update=1");
    mysqli_close($conn);
    exit();
}else{
    echo mysqli_error($conn);
    echo $vid . $category . $description . $title . $price;
    header("Location: ../watchVideo.php?vid=$vid&update=0");
    mysqli_close($conn);
    exit();
}
mysqli_close($conn);


?>