<?php
//Destroying previous session to prevent any issues
session_destroy();
//Check to make sure user is accessing register functionality properly
if(!isset($_POST["submit"])){
    header("Location ../register.php");
}



//Connect to DB
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
//Executing connection
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../register.php?error=sql");
}

//Grab post variables from form
$fname = mysqli_real_escape_string($conn, $_POST["fname"]);
$lname = mysqli_real_escape_string($conn, $_POST["lname"]);
$email = mysqli_real_escape_string($conn,$_POST["email"]);

//Check to see if email has already been registered
$checkSQL = "SELECT * FROM user WHERE email = '$email'";
$checkResult = mysqli_query($conn, $checkSQL);
if(mysqli_num_rows($checkResult) > 0){
    //If this code is ran, then the email is already registered
    //Send register.php back with the appropriate error message
    header("Location: ../register.php?error=registered");
}else{
    //BEFORE EXECUTING CODE BELOW WE NEED TO HAVE USER AUTHORIZE WITH CAS LOGIN
    //Code Here
    

    //If this is code is ran, the email has not been registered and we need to register user into our DB
    $insertUserSQL = "INSERT INTO user (fname, lname, email) VALUES ('$fname', '$lname', '$email')";
    $insertExecute = mysqli_query($conn, $insertUserSQL);

    //Now that user has been inserted I want to get their UID to add into their session
    $newUserSelectSQL = "SELECT userID FROM user WHERE email='$email'";
    $newUserResult = mysqli_query($conn, $newUserSelectSQL);
    $newUserAssoc = mysqli_fetch_assoc($newUserResult);
    $newUserID = (int)$newUserAssoc["userID"];

    //Now that database is updated with our new user we start our session to grab on other pages
    session_start();
    $_SESSION["uid"] = $newUserID;
    $_SESSION["fname"] = $fname;
    $_SESSION["lname"] = $lname;
    $_SESSION["email"] = $email;

    //Taking user to their profile. This will need to send user to home.php
    header("Location: ./profile.php?uid=$newUserID");

}
mysqli_close($conn);


?>