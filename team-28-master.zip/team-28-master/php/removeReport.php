<?php
session_start();
if(!isset($_SESSION["uid"])){
    header("Location: ../loginForm.php");
    exit();
}else{
    $sessionUser = $_SESSION["uid"];
}
//Connect to database
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php");
    exit();
}

//Making sure user accessing is admin
$adminQuery = "SELECT admin FROM user WHERE userID=$sessionUser";
$adminResult = mysqli_query($conn, $adminQuery);
$adminArray = mysqli_fetch_assoc($adminResult);
$admin = (int) $adminArray["admin"];
if($admin == 0){
    header("Location: ../index.php?error=admin");
    exit();
}


$vid = (int)$_GET["vid"];

if(!isset($_GET["vid"])){
    header("Location: ../adminHome.php?error=get");
    exit();
}


$deleteReportSQL = "DELETE FROM report WHERE videoID=$vid";
$deleteExecute = mysqli_query($conn, $deleteReportSQL);
if($deleteExecute){
header("Location: ../adminHome.php?del=1");
exit();
}else{
header("Location: ../adminHome.php?del=0");
exit();
}
mysqli_close($conn);
?>