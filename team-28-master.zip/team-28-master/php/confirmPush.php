<?php
//Checking to make sure user is logged in. 
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../loginForm.php");
    exit();
}
if(!isset($_POST["vid"])){
    header("Location: ../index.php?error=access");
    exit();
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
//Connecting to DB
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php?error=sql");
    exit();
}

//Grabbing videoID via POST
$vid = (int) $_POST["vid"];

//Get old video
//$oldVidsql = "SELECT * FROM video WHERE featured=1";
//$oldVidResult = mysqli_query($conn, $oldVidsql);
//$oldVidRow = mysqli_fetch_assoc($oldVidResult);
//$oldVidID = $oldVidRow["videoID"];
//$oldVidCategory = $oldVidRow["category"];
//$oldVidi = (int) mysqli_num_rows($oldVidRow);

//Get new video
$vidSelectsql = "SELECT * FROM video WHERE videoID=$vid";
$vidResult = mysqli_query($conn, $vidSelectsql);
$vidRow = mysqli_fetch_assoc($vidResult);
$vidCategory = $vidRow["category"];

//Get old video
$oldVidsql = "SELECT * FROM video WHERE featured=1 AND category='$vidCategory'";
$oldVidResult = mysqli_query($conn, $oldVidsql);
$oldVidAssoc = mysqli_fetch_assoc($oldVidResult);
//Getting ID and category for old featured video
$oldVidID = (int)$oldVidAssoc["videoID"];
$oldVidCat = $oldVidAssoc["category"];
//Updating featured to 0 for old featured video
$updateToNotFeatured = "UPDATE video SET featured = 0 WHERE category='$oldVidCat'";
mysqli_query($conn, $updateToNotFeatured);



//Looping through all old vids and updating them to not be featured anymore
/*while($row = mysqli_fetch_assoc($oldVidResult)){
    $oldVidID = $row["videoID"];
    $oldVidCat = $row["category"];
    $updateToNotFeatured = "UPDATE video SET featured = 0 WHERE videoID=$oldVidID AND category=$oldVidCat";
    mysqli_query($conn, $updateToNotFeatured);
}*/

//Go through video category
// for ($i = 0; $i < $oldVidi; $i++){
//     //See if the category is the same
//     if ("$oldVidCategory" == "$vidCategory") {
//         //Update old video
//         $oldUpdateSQL = "UPDATE video SET featured = 0 WHERE videoID=$oldVidID";
//         $oldUpdateResult = mysqli_query($conn, $oldUpdateSQL);
//     }
// }

//Updating video info from DB
$updateVidSQL = "UPDATE video SET featured = 1 WHERE videoID=$vid";
$updateVidResult = mysqli_query($conn, $updateVidSQL);

header("Location: ../index.php");
mysqli_close($conn);

?>