<?php
//Check session to make sure user editing profile 
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
session_start();

$sessionUser = $_SESSION["uid"];

if(!isset($_SESSION["uid"])){
    header("Location: ../loginForm.php");
    exit();
}



$profilePicDir = "/u/team28/cgi-pub/profilePics/";
//NEED TO UPDATE THIS FILE WHEN LOGIN AND LOGOUT SYSTEM INTEGRATED SO THAT ID IS NO LONGER HARD CODED


if (isset($_POST["submit"])) {
    //connecting to database
    $conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        header("Location: ../index.php?error=sql");
    }
    
    //Grabbing post variables
    $fname = mysqli_escape_string($conn,$_POST["fname"]);
    $lname = mysqli_escape_string($conn,$_POST["lname"]);
    $gender = mysqli_escape_string($conn,$_POST["gender"]);
    $standing = mysqli_escape_string($conn,$_POST["year"]);
    $bio = mysqli_escape_string($conn,$_POST["bio"]);
    $profilePic = $_POST["profilePic"];
    $interests = mysqli_escape_string($conn,$_POST["interests"]);
    $pronouns = mysqli_escape_string($conn,$_POST["pronouns"]);
    $major = mysqli_escape_string($conn,$_POST["major"]);
    //NEED TO CHANGE THIS TO BE DYNAMIC ONCE LOGIN IMPLEMENTED
    $userID = (int) $_POST["uid"];

    //DIRECTORY INFO
    

    //Checking to see if the user already has a profile
    $sql = "SELECT * FROM user_profile WHERE userID=$sessionUser";
    $result = mysqli_query($conn, $sql);

    //If there is already user profile data, we need to delete it and replace it with new user profile updated data
    if (mysqli_num_rows($result) == 1) {
        //Deleting the row
        //NEEDS TO BE UPDATED WHEN LOGIN SYSTEM DONE
        $deleteSQL = "DELETE FROM user_profile WHERE userID=$sessionUser";
        //Now need to update it with new info
        if (mysqli_query($conn, $deleteSQL)) {
            echo "Record deleted successfully";
            //Need to delete the old profile photo and upload new one

            $selectSQLArray = mysqli_fetch_assoc($result);
            $oldProfilePic = $selectSQLArray["profilePic"];
            //Deleting old profile pic
            $oldProfilePicPath = $profilePicDir . $oldProfilePic;
            if(file_exists($oldProfilePicPath)){
                unlink($oldProfilePicPath);
            }

            //Now that old row has been deleted, we can now insert the updated information and upload new profile pic
            ////$profileTemp = $_FILES["pic"]["name"][0];
            $profileTemp = $_FILES["pic"]["name"];
            $newProfileName = $userID . "_" . round(microtime(true)) . "_" . $profileTemp;

            //Uploading new file
            if (move_uploaded_file($_FILES["pic"]["tmp_name"][0], $profilePicDir . $newProfileName)) {
                echo 'File successfully uploaded';
            }

            $insertSQL = "INSERT INTO user_profile (userID, fname, lname, gender, standing, bio, profilePic, interests, pronouns, major) VALUES($userID,'$fname', '$lname', '$gender', '$standing', '$bio','$newProfileName','$interests','$pronouns','$major')";

            //Attempting to insert the record
            //Also uploading the new file 
            if (mysqli_query($conn, $insertSQL)) {
                echo 'Record Updated';
                header("Location: ../profile.php?process=success");
                exit();
            }else{
                header("../profile.php?error=sql");
                exit();
            }
        }else{
            header("../profile.php?error=sql");
            exit();
        }
    }else{
        //This else will get ran if this is the first time they are creating a profile
        
        $profileTemp = $_FILES["pic"]["name"];
        $newProfileName = $userID . "_" . round(microtime(true)) . "_" . $profileTemp;

        //Uploading new file
        if (move_uploaded_file($_FILES["pic"]["tmp_name"][0], $profilePicDir . $newProfileName)) {
            echo 'File successfully uploaded';
        }

        $insertSQL = "INSERT INTO user_profile (userID, fname, lname, gender, standing, bio, profilePic, interests, pronouns, major) VALUES($sessionUser,'$fname', '$lname', '$gender', '$standing', '$bio','$newProfileName','$interests','$pronouns','$major')";

        if (mysqli_query($conn, $insertSQL)) {
            echo 'Record Updated';
            header("Location: ../profile.php?process=success");
            exit();
        }else{
            header("../profile.php?error=sql");
            exit();
        }
        mysqli_close($conn);
    }
}else{
    header("Location: ../profile.php");
    exit();
}
mysqli_close($conn);

