<?php
//Check session to make sure user editing profile 
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

if (isset($_POST["submit"])) {

    $conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        header("Location: ../message.php?error=sql");
    }

    //info from user sending message
    $message = mysqli_real_escape_string($conn, $_POST["message"]);
    $senderID = (int) $_POST["senderID"];
    $receiverID = (int) $_POST["receiverID"];
    $date = date("Y-m-d");
    $time = date("H:i:s");

    echo $message . '\n';
    echo $senderID . '\n';
    echo $receiverID . '\n';
    echo $date . '\n';
    echo $time . '\n';



    $sql = "INSERT INTO message (receiverID, senderID, content, date, time) VALUES ($receiverID, $senderID, '$message','$date', '$time')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
        header("Location: ../message.php?uid=$receiverID&sent=success");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);


    //header("Location: ../message.php?sent=success");
} else {
    header("Location: ../index.php?error=access");
}
mysqli_close($conn);
