<?php
session_start();
$userID = $_SESSION["uid"];
//Making sure user is uploading via form.
if(isset($_POST["submit"])){
//DB Information
$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../upload.php?error=sql");
    exit();
}

//POST info
$title = mysqli_escape_string($conn, $_POST["title"]);
$description = nl2br(htmlentities($_POST["description"] ,ENT_QUOTES,'UTF-8'));
$category = $_POST["category"];
$price = (int) $_POST["price"];
$userID = (int) $_POST["userID"];
$launchDate = $_POST["reserve"];
$newLaunchDate = date('Y-m-d', strtotime($launchDate));
$date = date('Y-m-d');


//DIRECTORY info
$thumbDir = "/u/team28/cgi-pub/thumbnails/";
$vidDir = "/u/team28/cgi-pub/videos/";

//Building up unique thumbnail name
//Format is userID_Timestamp_filename
$thumbTemp = $_FILES["userfile"]["name"][0];
$newThumbName = $userID . "_" . round(microtime(true)) . '_' . $thumbTemp;

$vidTemp = $_FILES['userfile']['name'][1];
$newVidName = $userID . "_" . round(microtime(true)) . '_' . $vidTemp;

//Uploading files with if condition to ensure files properly uploaded
//If uploading error, user is taken back to upload page
if (move_uploaded_file($_FILES["userfile"]["tmp_name"][0], $thumbDir . $newThumbName)){
    echo "THUMBNAIL has been uploaded to thumbnail directory";
}else{
    echo "Upload Failed, please try again";
    header("Location: ../upload.php?error=upload");
}

if (move_uploaded_file($_FILES["userfile"]["tmp_name"][1], $vidDir . $newVidName)){
    echo "VIDEO has been uploaded to thumbnail directory";
}else{
    echo "Upload Failed, please try again";
    header("Location: ../upload.php?error=upload");
}

$thumbPath = $thumbDir . $newThumbName;
$vidPath = $vidDir . $newVidName;

//SQL Insert Video Information
$sql = "INSERT INTO video (title, vidDescription, uploadDate, category, ticketPrice, ownerID, thumbnailLocation, vidLocation, launchDate) VALUES ('$title', '$description', '$date', '$category', $price, $userID, '$newThumbName', '$newVidName', 
'$newLaunchDate')";


if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    header("Location: ../profile.php?uid=$userID&upload=success");
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  
mysqli_close($conn);




}else{
    echo "WRONG";
    header("Location: ../index.php?error=access");
    exit();
}
mysqli_close($conn);
?>