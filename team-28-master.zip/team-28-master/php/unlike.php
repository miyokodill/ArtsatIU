<?php

session_start(); 

if(isset($_SESSION["uid"])){
    $sessionUser = (int)$_SESSION["uid"];
    $vidPaid = (int)$_SESSION["vid"];
    $vidPrice = (int)$_SESSION["price"];
    $date = date('Y-m-d');
    $time = time();
}
else{
    header("Location: ../loginForm.php");
    exit();
}
$vid = (int) $_POST["vid"];

if(!isset($_POST["vid"])){
    header("Location: ../index.php?error=access");
    exit();
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
//In the future will want session var to take back to prev location
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php?error=sql");
    exit();
}

$deleteSQL = "DELETE FROM likes WHERE userID=$sessionUser AND videoID=$vid";

$result = mysqli_query($conn, $deleteSQL);
mysqli_close($conn);
if ($result){
    header("Location: ../watchVideo.php?vid=$vid&sql=success");
    exit();
}
else{
    header("Location: ../watchVideo.php?vid=$vid&error=sql");
    exit();
}
mysqli_close($conn);





?>