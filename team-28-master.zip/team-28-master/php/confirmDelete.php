<?php
//Checking to make sure user is logged in. 
session_start();


if (!isset($_SESSION["uid"])) {
    header("Location: ../loginForm.php");
    exit();
}else{
    $sessionUser = (int)$_SESSION["uid"];
}
if(!isset($_POST["vid"])){
    header("Location: ../index.php?error=access");
    exit();
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
//Connecting to DB
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../adminHome.php?error=sql");
    exit();
}

$justification = $_POST["report"];
if($justification == ""){
    header("Location: ../adminDelete.php?error=noJust");
    exit();
}

//Grabbing videoID via POST
$vid = (int) $_POST["vid"];

echo $vid;

//Need to get thumbnail and video name
$vidSelectsql = "SELECT * FROM video WHERE videoID=$vid";
$vidResult = mysqli_query($conn, $vidSelectsql);
$vidArray = mysqli_fetch_assoc($vidResult);

$vidOwner = (int) $vidArray["ownerID"];

//Getting the names of the files we need to delete
$vidLocation = $vidArray["vidLocation"];
$thumbnailLocation = $vidArray["thumbnailLocation"];


//need to delete any reports as well
$deleteReportsSQL = "DELETE FROM report WHERE videoID=$vid";
mysqli_query($conn,$deleteReportsSQL);

//NEed to delete likes before deleting video
$deleteLikesSQL = "DELETE FROM likes WHERE videoID=$vid";
mysqli_query($conn,$deleteLikesSQL);

$deleteCommentSQL = "DELETE FROM comments WHERE videoID=$vid";
mysqli_query($conn,$deleteCommentSQL);

$deleteViewsSQL = "DELETE FROM view WHERE videoID=$vid";
$deleteViewResult = mysqli_query($conn,$deleteViewsSQL);

//Deleting video info from DB
$deleteVidsql = "DELETE FROM video WHERE videoID= $vid";
//$deleteVidResult = mysqli_query($conn, $deleteVidsql);

$deleteTicketSalesSQL = "DELETE FROM ticketSale WHERE videoID=$vid";
mysqli_query($conn, $deleteTicketSalesSQL);

if (mysqli_query($conn, $deleteVidsql)) {
    echo "Record deleted successfully";
  } else {
    echo "Error deleting record: " . mysqli_error($conn);
  }

$thumbnailPath = "/u/team28/cgi-pub/thumbnails/" . $thumbnailLocation;
$videoPath = "/u/team28/cgi-pub/videos/" . $vidLocation;

//Unlinking videos from server
if(file_exists($thumbnailPath)){
    unlink($thumbnailPath);
}
if(file_exists($videoPath)){
    unlink($videoPath);
}
//
$insertViolationSQL = "INSERT INTO violationTicket (adminID, videoID, creatorID, justification) VALUES ($sessionUser, $vid, $vidOwner, '$justification')";
mysqli_query($conn, $insertViolationSQL);

header("Location: ../deleteConfirm.php");
mysqli_close($conn);

?>