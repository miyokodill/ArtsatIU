<?php
//Checking to make sure user is logged in. 
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../loginForm.php");
    exit();
}
if(!isset($_POST["user"])){
    header("Location: ../index.php?error=access");
    exit();
}

$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';
//Connecting to DB
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../adminHome.php?error=sql");
    exit();
}

//Grabbing videoID via POST
$userid = (int) $_POST["user"];

//Get new video
$sql = "SELECT * FROM user WHERE userID=$userid";
$result = mysqli_query($conn, $sql);
$array = mysqli_fetch_assoc($result);

//Updating video info from DB
$updateUserSQL = "UPDATE user SET admin = 1 WHERE userID=$userid";
$updateUserResult = mysqli_query($conn, $updateUserSQL);

header("Location: ../php/userAdded.php");
mysqli_close($conn);
?>