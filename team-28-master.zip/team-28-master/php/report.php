<?php
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../loginForm.php");
    exit();
}else{
    $sessionUser = (int)$_SESSION["uid"];
}

//Grabbing POST variables
$vid = (int) $_POST["video"];

if(!isset($_POST["video"])){
    header("Location: ../index.php?error=access");
    exit();
}

//Creatng necesarry date and time vars for sql
$date = date('Y-m-d');
$time = date("H:i:s");


$DB_HOST = 'db.luddy.indiana.edu';
$DB_NAME = 'i494f20_team28';
$DB_USER = 'i494f20_team28';
$DB_PWD = 'my+sql=i494f20_team28';

//Connecting to database
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PWD, $DB_NAME);
//Check DB connection
if(!$conn){
    die("Connection failed: " . mysqli_connect_error());
    header("Location: ../index.php?error=sql");
}

//updating database with new inappropriate content report
$insertSQL = "INSERT INTO report(reporterID, videoID, date, time) VALUES ($sessionUser, $vid, '$date', '$time')";
$result = mysqli_query($conn, $insertSQL);
if($result){
    echo 'SUCCESS';
    header("Location: ../watchVideo.php?vid=$vid&report=1");
    exit();
}else{
    echo 'FAIL';
    echo "VIDEO: " . $vid . "<br>";
    echo "USER: " . $sessionUser;
    header("Location: ../watchVideo.php?vid=$vid&report=0");
    exit();
}
mysqli_close($conn);

?>