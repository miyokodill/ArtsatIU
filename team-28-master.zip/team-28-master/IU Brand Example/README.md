This folder has the basics for building a simple IU webpage. It will be updated to contain more elements. Please follow the layout when building your page.

Add rvt.css and rvt.js whenever using any assets from form.html
